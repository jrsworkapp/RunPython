// test-mocks/mock-api.js
const http = require('http');

// In-memory databases
const users = [
  { id: 1, name: 'User One', email: 'user1@example.com', role: 'user', active: true },
  { id: 2, name: 'User Two', email: 'user2@example.com', role: 'lawyer', active: true }
];

const litigationCases = [];
const documents = [];
const hearings = [];
const timeline = [];
const parties = [];

let nextUserId = 3;
let nextCaseId = 1;
let nextDocId = 1;
let nextHearingId = 1;
let nextTimelineId = 1;
let nextPartyId = 1;


const crypto = require('crypto');

function base64url(input) {
  return Buffer.from(input)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function sign(payload, secret) {
  return crypto.createHmac('sha256', secret).update(payload).digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function generateJwt(claims = {}, secret = 'mock-secret', expiresInSeconds = 3600) {
  const header = { alg: 'HS256', typ: 'JWT' };
  const iat = Math.floor(Date.now() / 1000);
  const payload = { iat, exp: iat + expiresInSeconds, ...claims };
  const encodedHeader = base64url(JSON.stringify(header));
  const encodedPayload = base64url(JSON.stringify(payload));
  const signature = sign(`${encodedHeader}.${encodedPayload}`, secret);
  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

const server = http.createServer((req, res) => {
  // Set CORS headers for all requests
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Helper to read JSON body
  function readJsonBody(request) {
    return new Promise((resolve, reject) => {
      let data = '';
      request.on('data', chunk => (data += chunk));
      request.on('end', () => {
        try {
          const parsed = data ? JSON.parse(data) : {};
          resolve(parsed);
        } catch (err) {
          reject(err);
        }
      });
      request.on('error', reject);
    });
  }

  // Auth endpoint: POST /auth/login
  if (req.method === 'POST' && req.url === '/auth/login') {
    readJsonBody(req).then(body => {
      const username = body.username || body.user || body.email || body.emailAddress || body.login;
      const password = body.password || body.pass || body.pw;

      if (username === 'admin' && password === 'admin') {
        const token = generateJwt({ sub: 'admin', role: 'admin' });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ token }));
        return;
      }

      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Unauthorized' }));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }

  // Serve OpenAPI spec
  if (req.method === 'GET' && req.url === '/openapi.json') {
    const openapi = {
      openapi: '3.0.0',
      info: { 
        title: 'Mock API - Sistema de Litígios', 
        version: '2.0.0',
        description: 'API completa para gerenciamento de processos judiciais, usuários, documentos e audiências'
      },
      servers: [{ url: 'http://localhost:3333' }],
      paths: {
        '/auth/login': {
          post: {
            summary: 'Authenticate and obtain JWT token',
            tags: ['Authentication'],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      username: { type: 'string', example: 'admin' },
                      password: { type: 'string', example: 'admin' }
                    },
                    required: ['username', 'password']
                  }
                }
              }
            },
            responses: {
              '200': {
                description: 'Authentication successful',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        token: { type: 'string' }
                      }
                    }
                  }
                }
              },
              '400': { description: 'Invalid JSON or bad request' },
              '401': { description: 'Unauthorized - invalid credentials' }
            }
          }
        },
        '/users': {
          get: {
            summary: 'List users with filters',
            tags: ['Users'],
            parameters: [
              {
                name: 'role',
                in: 'query',
                schema: { type: 'string', enum: ['user', 'lawyer', 'client', 'admin'] },
                description: 'Filter by user role'
              },
              {
                name: 'active',
                in: 'query',
                schema: { type: 'boolean' },
                description: 'Filter by active status'
              },
              {
                name: 'limit',
                in: 'query',
                schema: { type: 'integer', default: 10 },
                description: 'Number of results per page'
              },
              {
                name: 'page',
                in: 'query',
                schema: { type: 'integer', default: 1 },
                description: 'Page number'
              }
            ],
            responses: {
              '200': {
                description: 'A list of users',
                content: {
                  'application/json': {
                    schema: {
                      type: 'array',
                      items: {
                        type: 'object',
                        properties: {
                          id: { type: 'integer' },
                          name: { type: 'string' },
                          email: { type: 'string' },
                          role: { type: 'string' },
                          active: { type: 'boolean' },
                          createdAt: { type: 'string', format: 'date-time' }
                        }
                      }
                    }
                  }
                }
              }
            }
          },
          post: {
            summary: 'Create new user',
            tags: ['Users'],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      name: { type: 'string' },
                      email: { type: 'string', format: 'email' },
                      role: { type: 'string', enum: ['user', 'lawyer', 'client', 'admin'], default: 'user' }
                    },
                    required: ['name', 'email']
                  }
                }
              }
            },
            responses: {
              '201': {
                description: 'User created successfully',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        id: { type: 'integer' },
                        name: { type: 'string' },
                        email: { type: 'string' },
                        role: { type: 'string' },
                        active: { type: 'boolean' },
                        createdAt: { type: 'string', format: 'date-time' }
                      }
                    }
                  }
                }
              }
            }
          }
        },
        '/users/{id}': {
          get: {
            summary: 'Get user by ID',
            tags: ['Users'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'User ID'
              }
            ],
            responses: {
              '200': {
                description: 'User details',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        id: { type: 'integer' },
                        name: { type: 'string' },
                        email: { type: 'string' },
                        role: { type: 'string' },
                        active: { type: 'boolean' },
                        createdAt: { type: 'string', format: 'date-time' }
                      }
                    }
                  }
                }
              },
              '404': {
                description: 'User not found'
              }
            }
          },
          put: {
            summary: 'Update user',
            tags: ['Users'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'User ID'
              }
            ],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      name: { type: 'string' },
                      email: { type: 'string', format: 'email' },
                      role: { type: 'string' },
                      active: { type: 'boolean' }
                    }
                  }
                }
              }
            },
            responses: {
              '200': {
                description: 'User updated successfully'
              },
              '404': {
                description: 'User not found'
              }
            }
          },
          delete: {
            summary: 'Delete user',
            tags: ['Users'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'User ID'
              }
            ],
            responses: {
              '204': {
                description: 'User deleted successfully'
              },
              '404': {
                description: 'User not found'
              }
            }
          }
        },
        '/users/{id}/deactivate': {
          patch: {
            summary: 'Deactivate user (soft delete)',
            tags: ['Users'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'User ID'
              }
            ],
            responses: {
              '200': {
                description: 'User deactivated successfully'
              },
              '404': {
                description: 'User not found'
              }
            }
          }
        },
        '/litigation/cases': {
          post: {
            summary: 'Create new litigation case',
            tags: ['Litigation Cases'],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      title: { type: 'string' },
                      description: { type: 'string' },
                      category: { type: 'string', enum: ['civil', 'criminal', 'trabalhista', 'tributario'] },
                      priority: { type: 'string', enum: ['low', 'medium', 'high'], default: 'medium' },
                      status: { type: 'string', enum: ['active', 'pending', 'approved', 'closed'], default: 'active' }
                    },
                    required: ['title', 'description', 'category']
                  }
                }
              }
            },
            responses: {
              '201': {
                description: 'Litigation case created successfully',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        id: { type: 'integer' },
                        title: { type: 'string' },
                        description: { type: 'string' },
                        category: { type: 'string' },
                        priority: { type: 'string' },
                        status: { type: 'string' },
                        createdAt: { type: 'string', format: 'date-time' }
                      }
                    }
                  }
                }
              }
            }
          }
        },
        '/litigation/cases/{id}': {
          get: {
            summary: 'Get litigation case by ID',
            tags: ['Litigation Cases'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'Case ID'
              }
            ],
            responses: {
              '200': {
                description: 'Case details with related data',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        id: { type: 'integer' },
                        title: { type: 'string' },
                        description: { type: 'string' },
                        category: { type: 'string' },
                        priority: { type: 'string' },
                        status: { type: 'string' },
                        parties: { type: 'array', items: { type: 'object' } },
                        documents: { type: 'array', items: { type: 'object' } },
                        timeline: { type: 'array', items: { type: 'object' } },
                        hearings: { type: 'array', items: { type: 'object' } },
                        createdAt: { type: 'string', format: 'date-time' }
                      }
                    }
                  }
                }
              },
              '404': {
                description: 'Case not found'
              }
            }
          },
          delete: {
            summary: 'Delete litigation case and all related data',
            tags: ['Litigation Cases'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'Case ID'
              }
            ],
            responses: {
              '204': {
                description: 'Case deleted successfully'
              },
              '404': {
                description: 'Case not found'
              }
            }
          }
        },
        '/litigation/cases/{id}/parties': {
          post: {
            summary: 'Add party to litigation case',
            tags: ['Case Management'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'Case ID'
              }
            ],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      partyId: { type: 'string' },
                      role: { type: 'string', enum: ['client', 'lawyer', 'defendant', 'witness'] }
                    },
                    required: ['partyId', 'role']
                  }
                }
              }
            },
            responses: {
              '201': {
                description: 'Party added to case successfully'
              },
              '404': {
                description: 'Case not found'
              }
            }
          }
        },
        '/litigation/cases/{id}/timeline': {
          post: {
            summary: 'Add timeline event to case',
            tags: ['Case Management'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'Case ID'
              }
            ],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      event: { type: 'string' },
                      date: { type: 'string', format: 'date-time' },
                      description: { type: 'string' }
                    },
                    required: ['event', 'date']
                  }
                }
              }
            },
            responses: {
              '201': {
                description: 'Timeline event added successfully'
              },
              '404': {
                description: 'Case not found'
              }
            }
          }
        },
        '/litigation/cases/{id}/documents': {
          post: {
            summary: 'Add document to case',
            tags: ['Document Management'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'Case ID'
              }
            ],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      name: { type: 'string' },
                      type: { type: 'string', enum: ['petition', 'evidence', 'contract', 'correspondence', 'other'] },
                      content: { type: 'string', description: 'Document content or file path' }
                    },
                    required: ['name', 'type']
                  }
                }
              }
            },
            responses: {
              '201': {
                description: 'Document added to case successfully'
              },
              '404': {
                description: 'Case not found'
              }
            }
          }
        },
        '/litigation/cases/{id}/hearings': {
          post: {
            summary: 'Schedule hearing for case',
            tags: ['Hearing Management'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'Case ID'
              }
            ],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      type: { type: 'string', enum: ['initial', 'testimony', 'sentencing', 'appeal'] },
                      date: { type: 'string', format: 'date-time' },
                      location: { type: 'string' },
                      notes: { type: 'string' }
                    },
                    required: ['type', 'date', 'location']
                  }
                }
              }
            },
            responses: {
              '201': {
                description: 'Hearing scheduled successfully'
              },
              '404': {
                description: 'Case not found'
              }
            }
          }
        },
        '/litigation/cases/{id}/submit-approval': {
          patch: {
            summary: 'Submit case for approval',
            tags: ['Case Workflow'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'Case ID'
              }
            ],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      approverId: { type: 'string' }
                    },
                    required: ['approverId']
                  }
                }
              }
            },
            responses: {
              '200': {
                description: 'Case submitted for approval successfully'
              },
              '404': {
                description: 'Case not found'
              }
            }
          }
        },
        '/litigation/cases/{id}/approve': {
          patch: {
            summary: 'Approve case',
            tags: ['Case Workflow'],
            parameters: [
              {
                name: 'id',
                in: 'path',
                required: true,
                schema: { type: 'integer' },
                description: 'Case ID'
              }
            ],
            responses: {
              '200': {
                description: 'Case approved successfully'
              },
              '404': {
                description: 'Case not found'
              }
            }
          }
        }
      },
      tags: [
        { name: 'Authentication', description: 'Authentication and authorization' },
        { name: 'Users', description: 'User management operations' },
        { name: 'Litigation Cases', description: 'Litigation case management' },
        { name: 'Case Management', description: 'Case parties and timeline management' },
        { name: 'Document Management', description: 'Case document management' },
        { name: 'Hearing Management', description: 'Hearing scheduling and management' },
        { name: 'Case Workflow', description: 'Case approval and workflow operations' }
      ]
    };

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(openapi, null, 2));
    return;
  }

  // Serve Swagger UI page (uses CDN)
  if (req.method === 'GET' && (req.url === '/docs' || req.url === '/docs/')) {
    const html = `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Mock API - Swagger UI</title>
    <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@4/swagger-ui.css" />
  </head>
  <body>
    <div id="swagger-ui"></div>
    <script src="https://unpkg.com/swagger-ui-dist@4/swagger-ui-bundle.js"></script>
    <script>
      window.ui = SwaggerUIBundle({
        url: '/openapi.json',
        dom_id: '#swagger-ui',
        presets: [SwaggerUIBundle.presets.apis],
      });
    </script>
  </body>
</html>`;

    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
    return;
  }

  // === USER ENDPOINTS ===
  
  // GET /users - List users with filters
  if (req.method === 'GET' && (req.url === '/users' || req.url.startsWith('/users?'))) {
    const url = new URL(req.url, 'http://localhost');
    const role = url.searchParams.get('role');
    const active = url.searchParams.get('active');
    const limit = parseInt(url.searchParams.get('limit')) || 10;
    const page = parseInt(url.searchParams.get('page')) || 1;
    
    let filteredUsers = users.filter(user => {
      if (role && user.role !== role) return false;
      if (active !== null && user.active !== (active === 'true')) return false;
      return true;
    });
    
    const start = (page - 1) * limit;
    const paginatedUsers = filteredUsers.slice(start, start + limit);
    
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(paginatedUsers));
    return;
  }
  
  // POST /users - Create user
  if (req.method === 'POST' && req.url === '/users') {
    readJsonBody(req).then(body => {
      const newUser = {
        id: nextUserId++,
        name: body.name,
        email: body.email,
        role: body.role || 'user',
        active: true,
        createdAt: new Date().toISOString()
      };
      users.push(newUser);
      
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newUser));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }
  
  // GET /users/:id - Get user by ID
  if (req.method === 'GET' && req.url.match(/^\/users\/\d+$/)) {
    const userId = parseInt(req.url.split('/')[2]);
    const user = users.find(u => u.id === userId);
    
    if (!user) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'User not found' }));
      return;
    }
    
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(user));
    return;
  }
  
  // PUT /users/:id - Update user
  if (req.method === 'PUT' && req.url.match(/^\/users\/\d+$/)) {
    const userId = parseInt(req.url.split('/')[2]);
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'User not found' }));
      return;
    }
    
    readJsonBody(req).then(body => {
      users[userIndex] = { ...users[userIndex], ...body, updatedAt: new Date().toISOString() };
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(users[userIndex]));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }
  
  // PATCH /users/:id/deactivate - Deactivate user
  if (req.method === 'PATCH' && req.url.match(/^\/users\/\d+\/deactivate$/)) {
    const userId = parseInt(req.url.split('/')[2]);
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'User not found' }));
      return;
    }
    
    users[userIndex].active = false;
    users[userIndex].deactivatedAt = new Date().toISOString();
    
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(users[userIndex]));
    return;
  }
  
  // DELETE /users/:id - Delete user
  if (req.method === 'DELETE' && req.url.match(/^\/users\/\d+$/)) {
    const userId = parseInt(req.url.split('/')[2]);
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'User not found' }));
      return;
    }
    
    users.splice(userIndex, 1);
    res.writeHead(204);
    res.end();
    return;
  }
  
  // === LITIGATION ENDPOINTS ===
  
  // GET /litigation/cases - List all litigation cases
  if (req.method === 'GET' && req.url === '/litigation/cases') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(litigationCases));
    return;
  }

  // GET /documents - List all documents
  if (req.method === 'GET' && req.url === '/documents') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(documents));
    return;
  }

  // POST /documents - Create document
  if (req.method === 'POST' && req.url === '/documents') {
    readJsonBody(req).then(body => {
      const newDocument = {
        id: nextDocId++,
        name: body.name,
        type: body.type,
        caseId: body.caseId,
        uploadedAt: new Date().toISOString()
      };
      documents.push(newDocument);
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newDocument));
    });
    return;
  }

  // GET /hearings - List all hearings
  if (req.method === 'GET' && req.url === '/hearings') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(hearings));
    return;
  }

  // POST /hearings - Create hearing
  if (req.method === 'POST' && req.url === '/hearings') {
    readJsonBody(req).then(body => {
      const newHearing = {
        id: nextHearingId++,
        type: body.type,
        date: body.date,
        time: body.time,
        location: body.location,
        caseId: body.caseId,
        status: body.status || 'scheduled',
        createdAt: new Date().toISOString()
      };
      hearings.push(newHearing);
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newHearing));
    });
    return;
  }

  // DELETE /hearings/:id - Delete hearing
  if (req.method === 'DELETE' && req.url.match(/^\/hearings\/\d+$/)) {
    const hearingId = parseInt(req.url.split('/')[2]);
    const hearingIndex = hearings.findIndex(h => h.id === hearingId);
    if (hearingIndex === -1) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Hearing not found' }));
      return;
    }
    hearings.splice(hearingIndex, 1);
    res.writeHead(204);
    res.end();
    return;
  }

  // POST /litigation/cases - Create litigation case
  if (req.method === 'POST' && req.url === '/litigation/cases') {
    readJsonBody(req).then(body => {
      const newCase = {
        id: nextCaseId++,
        title: body.title,
        description: body.description,
        category: body.category,
        priority: body.priority || 'medium',
        status: body.status || 'active',
        createdAt: new Date().toISOString(),
        parties: []
      };
      litigationCases.push(newCase);
      
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newCase));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }
  
  // GET /litigation/cases/:id - Get case by ID
  if (req.method === 'GET' && req.url.match(/^\/litigation\/cases\/\d+$/)) {
    const caseId = parseInt(req.url.split('/')[3]);
    const litigationCase = litigationCases.find(c => c.id === caseId);
    
    if (!litigationCase) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Case not found' }));
      return;
    }
    
    // Include related data
    const caseParties = parties.filter(p => p.caseId === caseId);
    const caseTimeline = timeline.filter(t => t.caseId === caseId);
    
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ...litigationCase, parties: caseParties, timeline: caseTimeline }));
    return;
  }
  
  // POST /litigation/cases/:id/parties - Add party to case
  if (req.method === 'POST' && req.url.match(/^\/litigation\/cases\/\d+\/parties$/)) {
    const caseId = parseInt(req.url.split('/')[3]);
    const litigationCase = litigationCases.find(c => c.id === caseId);
    
    if (!litigationCase) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Case not found' }));
      return;
    }
    
    readJsonBody(req).then(body => {
      const newParty = {
        id: nextPartyId++,
        caseId: caseId,
        partyId: body.partyId,
        role: body.role
      };
      parties.push(newParty);
      
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newParty));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }
  
  // POST /litigation/cases/:id/timeline - Add timeline event
  if (req.method === 'POST' && req.url.match(/^\/litigation\/cases\/\d+\/timeline$/)) {
    const caseId = parseInt(req.url.split('/')[3]);
    
    readJsonBody(req).then(body => {
      const newEvent = {
        id: nextTimelineId++,
        caseId: caseId,
        event: body.event,
        date: body.date,
        description: body.description
      };
      timeline.push(newEvent);
      
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newEvent));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }
  
  // POST /litigation/cases/:id/documents - Add documents to case
  if (req.method === 'POST' && req.url.match(/^\/litigation\/cases\/\d+\/documents$/)) {
    const caseId = parseInt(req.url.split('/')[3]);
    
    readJsonBody(req).then(body => {
      const newDocument = {
        id: nextDocId++,
        caseId: caseId,
        title: body.title,
        type: body.type,
        content: body.content,
        uploadDate: body.uploadDate || new Date().toISOString()
      };
      documents.push(newDocument);
      
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newDocument));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }
  
  // PATCH /litigation/cases/:id/submit-approval - Submit for approval
  if (req.method === 'PATCH' && req.url.match(/^\/litigation\/cases\/\d+\/submit-approval$/)) {
    const caseId = parseInt(req.url.split('/')[3]);
    const caseIndex = litigationCases.findIndex(c => c.id === caseId);
    
    if (caseIndex === -1) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Case not found' }));
      return;
    }
    
    litigationCases[caseIndex].status = 'pending_approval';
    litigationCases[caseIndex].submittedAt = new Date().toISOString();
    
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(litigationCases[caseIndex]));
    return;
  }
  
  // PATCH /litigation/cases/:id/approve - Approve case
  if (req.method === 'PATCH' && req.url.match(/^\/litigation\/cases\/\d+\/approve$/)) {
    const caseId = parseInt(req.url.split('/')[3]);
    const caseIndex = litigationCases.findIndex(c => c.id === caseId);
    
    if (caseIndex === -1) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Case not found' }));
      return;
    }
    
    readJsonBody(req).then(body => {
      litigationCases[caseIndex].status = 'approved';
      litigationCases[caseIndex].approvedAt = new Date().toISOString();
      litigationCases[caseIndex].approverId = body.approverId;
      litigationCases[caseIndex].approvalNotes = body.notes;
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(litigationCases[caseIndex]));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }
  
  // POST /litigation/cases/:id/hearings - Schedule hearing
  if (req.method === 'POST' && req.url.match(/^\/litigation\/cases\/\d+\/hearings$/)) {
    const caseId = parseInt(req.url.split('/')[3]);
    
    readJsonBody(req).then(body => {
      const newHearing = {
        id: nextHearingId++,
        caseId: caseId,
        scheduledDate: body.scheduledDate,
        hearingType: body.hearingType,
        location: body.location,
        judgeId: body.judgeId,
        status: body.status || 'scheduled'
      };
      hearings.push(newHearing);
      
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newHearing));
    }).catch(() => {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Invalid JSON' }));
    });
    return;
  }
  
  // DELETE /litigation/cases/:id - Delete case
  if (req.method === 'DELETE' && req.url.match(/^\/litigation\/cases\/\d+$/)) {
    const caseId = parseInt(req.url.split('/')[3]);
    const caseIndex = litigationCases.findIndex(c => c.id === caseId);
    
    if (caseIndex === -1) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Case not found' }));
      return;
    }
    
    // Clean up related data
    litigationCases.splice(caseIndex, 1);
    const relatedParties = parties.filter(p => p.caseId === caseId);
    relatedParties.forEach(p => parties.splice(parties.indexOf(p), 1));
    const relatedDocs = documents.filter(d => d.caseId === caseId);
    relatedDocs.forEach(d => documents.splice(documents.indexOf(d), 1));
    const relatedTimeline = timeline.filter(t => t.caseId === caseId);
    relatedTimeline.forEach(t => timeline.splice(timeline.indexOf(t), 1));
    const relatedHearings = hearings.filter(h => h.caseId === caseId);
    relatedHearings.forEach(h => hearings.splice(hearings.indexOf(h), 1));
    
    res.writeHead(204);
    res.end();
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ message: 'Not found' }));
});

const port = 3333;
server.listen(port, () => {
  console.log(`Mock API listening on http://localhost:${port}`);
  console.log(`Swagger UI available at http://localhost:${port}/docs`);
});

// Graceful shutdown
process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));