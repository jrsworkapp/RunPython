#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

function escapeXml(unsafe) {
  if (!unsafe) return '';
  return unsafe.replace(/[<>&'\"]/g, function (c) {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case "'": return '&apos;';
      case '"': return '&quot;';
    }
  });
}

function toJUnit(cucumberJson) {
  const testsuites = [];
  cucumberJson.forEach(feature => {
    const suite = {
      name: feature.name || feature.uri || 'Feature',
      testcases: []
    };
    const elements = feature.elements || [];
    elements.forEach(element => {
      if (element.type !== 'scenario' && element.type !== 'background') return;
      const caseName = element.name || element.keyword || 'Scenario';
      let status = 'passed';
      const steps = element.steps || [];
      let failureMessage = null;
      for (const step of steps) {
        const result = step.result || {};
        if (result.status === 'failed') {
          status = 'failed';
          failureMessage = (result.message) ? result.message : JSON.stringify(result);
          break;
        }
        if (result.status === 'skipped' || result.status === 'pending' || result.status === 'undefined') {
          status = 'skipped';
        }
      }
      suite.testcases.push({ name: caseName, status, failureMessage });
    });
    testsuites.push(suite);
  });

  // Build XML
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<testsuites>\n';
  testsuites.forEach(suite => {
    const tests = suite.testcases.length;
    const failures = suite.testcases.filter(tc => tc.status === 'failed').length;
    const skipped = suite.testcases.filter(tc => tc.status === 'skipped').length;
    xml += `  <testsuite name="${escapeXml(suite.name)}" tests="${tests}" failures="${failures}" skipped="${skipped}">\n`;
    suite.testcases.forEach(tc => {
      xml += `    <testcase name="${escapeXml(tc.name)}">`;
      if (tc.status === 'failed') {
        xml += `\n      <failure>${escapeXml(tc.failureMessage || 'failed')}</failure>`;
        xml += '\n    ';
      }
      if (tc.status === 'skipped') {
        xml += '\n      <skipped/>';
        xml += '\n    ';
      }
      xml += `</testcase>\n`;
    });
    xml += '  </testsuite>\n';
  });
  xml += '</testsuites>\n';
  return xml;
}

function main() {
  const input = path.resolve(process.cwd(), 'reports', 'cucumber.json');
  const outDir = path.resolve(process.cwd(), 'reports');
  const output = path.resolve(outDir, 'cucumber-junit.xml');
  if (!fs.existsSync(input)) {
    console.error('cucumber.json not found at', input);
    process.exit(2);
  }
  const data = JSON.parse(fs.readFileSync(input, 'utf8'));
  const xml = toJUnit(data);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(output, xml, 'utf8');
  console.log('Wrote JUnit to', output);
}

if (require.main === module) main();
