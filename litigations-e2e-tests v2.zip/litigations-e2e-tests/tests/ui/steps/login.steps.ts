import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { LoginPage } from '../support/LoginPage';

Given('que estou na página de login', async function () {
  // `this.page` is provided by the Cucumber Before hook (tests/steps/hooks.ts)
  this.loginPage = new LoginPage(this.page);
  await this.loginPage.goto();
});

When('eu preencho usuário {string} e senha {string}', async function (user: string, pass: string) {
  await this.loginPage.fillEmail(user);
  await this.loginPage.fillPassword(pass);
});

When('clico no botão de login', async function () {
  await this.loginPage.submit();
});

Then('devo ver a mensagem de boas-vindas {string}', async function (msg: string) {
  const visible = await this.loginPage.hasWelcomeMessage();
  expect(visible).toBeTruthy();
  const text = await this.loginPage.getWelcomeText();
  if (text) expect(text).toContain(msg);
});

// === NOVOS STEPS USANDO LOGIN PAGE ===

When('eu faço login completo com usuário {string} e senha {string}', async function (email: string, password: string) {
  await this.loginPage.fillEmail(email);
  await this.loginPage.fillPassword(password);
  await this.loginPage.submit();
  
  // Aguarda o redirecionamento
  await this.page.waitForURL('**/dashboard', { timeout: 5000 });
  
  this.loginResult = {
    success: true,
    currentUrl: this.page.url()
  };
});

Then('devo estar logado com sucesso no dashboard', async function () {
  expect(this.loginResult.success).toBe(true);
  expect(this.loginResult.currentUrl).toContain('dashboard');
});

When('eu tento fazer login com credenciais inválidas {string} e {string}', async function (email: string, password: string) {
  await this.loginPage.fillEmail(email);
  await this.loginPage.fillPassword(password);
  await this.loginPage.submit();
  
  // Verifica se ainda está na página de login
  const currentUrl = this.page.url();
  const stayedOnLogin = currentUrl.includes('login') || currentUrl.includes('localhost:3000');
  
  this.loginResult = {
    success: false,
    stayedOnLogin: stayedOnLogin
  };
});

Then('devo permanecer na página de login', async function () {
  expect(this.loginResult.success).toBe(false);
  expect(this.loginResult.stayedOnLogin).toBe(true);
});

When('eu faço logout do sistema', async function () {
  // Procura o botão/link de logout (assumindo que existe no dashboard)
  await this.page.click('text=Sair');
  
  // Aguarda o redirecionamento para login
  await this.page.waitForURL('**/login', { timeout: 5000 });
  
  this.logoutResult = {
    success: true
  };
});

Then('devo ser redirecionado para a página de login', async function () {
  expect(this.logoutResult.success).toBe(true);
});
