// test-mocks/mock-ui.js
const http = require('http');

const loginPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Login - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      html,body,#root{height:100%;margin:0;font-family:Arial, sans-serif}
      .login-container{display:flex;justify-content:center;align-items:center;height:100vh;background:#f5f5f5}
      .login-form{background:white;padding:2rem;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,0.1);max-width:400px;width:100%}
      .form-title{text-align:center;color:#1976d2;margin-bottom:1.5rem;font-size:1.5rem}
      .form-group{margin-bottom:1rem}
      .form-label{display:block;margin-bottom:0.25rem;font-weight:500;color:#333}
      .form-input{width:100%;padding:0.75rem;border:1px solid #ddd;border-radius:4px;font-size:1rem;box-sizing:border-box}
      .form-input:focus{outline:none;border-color:#1976d2}
      .login-button{width:100%;background:#1976d2;color:white;padding:0.75rem;border:none;border-radius:4px;font-size:1rem;cursor:pointer;margin-top:0.5rem}
      .login-button:hover{background:#1565c0}
      .error-message{color:#d32f2f;font-size:0.875rem;margin-top:0.5rem;text-align:center}
      .success-message{color:#4caf50;font-size:0.875rem;margin-top:0.5rem;text-align:center}
    </style>
  </head>
  <body>
    <div id="root" class="login-container">
      <div class="login-form">
        <h2 class="form-title">Sistema Jurídico</h2>
        <form>
          <div class="form-group">
            <label class="form-label" for="username">Usuário:</label>
            <input type="text" class="form-input" id="username" name="username" />
          </div>
          <div class="form-group">
            <label class="form-label" for="password">Senha:</label>
            <input type="password" class="form-input" id="password" name="password" />
          </div>
          <button type="button" class="login-button" onclick="performLogin()">Entrar</button>
          <div class="error-message" id="error-message" style="display: none;"></div>
          <div class="success-message" id="success-message" style="display: none;">Bem-vindo</div>
        </form>
      </div>
    </div>

    <script>
      function performLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorMsg = document.getElementById('error-message');
        const successMsg = document.getElementById('success-message');

        errorMsg.style.display = 'none';
        successMsg.style.display = 'none';

        if (!username || !password) {
          errorMsg.textContent = 'Por favor, preencha todos os campos';
          errorMsg.style.display = 'block';
          return;
        }

        if (username === 'user@test.com' && password === '123456') {
          successMsg.style.display = 'block';
          setTimeout(() => {
            window.location.href = '/dashboard';
          }, 1000);
        } else {
          errorMsg.textContent = 'Credenciais inválidas';
          errorMsg.style.display = 'block';
        }
      }

      // Handle Enter key
      document.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
          performLogin();
        }
      });
    </script>
  </body>
</html>
`;

const dashboardPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Dashboard - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      html,body{height:100%;margin:0;font-family:Arial, sans-serif}
      .dashboard{padding:2rem;background:#f5f5f5;min-height:100vh}
      .header{background:white;padding:1rem 2rem;margin-bottom:2rem;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}
      .welcome{color:#1976d2;font-size:1.5rem;margin:0}
      .logout-btn{background:#d32f2f;color:white;border:none;padding:0.5rem 1rem;border-radius:4px;cursor:pointer;float:right}
      .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:2rem;margin-top:2rem}
      .card{background:white;padding:1.5rem;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}
      .card h3{color:#1976d2;margin:0 0 1rem 0}
      .card button{background:#1976d2;color:white;border:none;padding:0.5rem 1rem;border-radius:4px;cursor:pointer}
    </style>
  </head>
  <body>
    <div class="dashboard">
      <div class="header">
        <h1 class="welcome">Bem-vindo ao Sistema Jurídico</h1>
        <button class="logout-btn" onclick="logout()">Sair</button>
        <div style="clear:both"></div>
      </div>
      
      <div class="cards">
        <div class="card">
          <h3>Casos</h3>
          <p>Gerencie processos judiciais</p>
          <button onclick="window.location.href='/cases'">Ver Casos</button>
        </div>
        
        <div class="card">
          <h3>Documentos</h3>
          <p>Upload e gerenciamento de documentos</p>
          <button>Ver Documentos</button>
        </div>
        
        <div class="card">
          <h3>Audiências</h3>
          <p>Agende e gerencie audiências</p>
          <button>Ver Audiências</button>
        </div>
      </div>
    </div>

    <script>
      function logout() {
        window.location.href = '/login';
      }
    </script>
  </body>
</html>
`;

const server = http.createServer((req, res) => {
  const url = req.url;
  
  // Route handling
  if (req.method === 'GET' && url === '/login') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(loginPage);
    return;
  }
  
  if (req.method === 'GET' && url === '/dashboard') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(dashboardPage);
    return;
  }
  
  // Default redirect to login for root
  if (req.method === 'GET' && (url === '/' || url === '')) {
    res.writeHead(302, { 'Location': '/login' });
    res.end();
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end('<h1>404 - Page Not Found</h1><p><a href="/login">Go to Login</a></p>');
});

const port = 3000;
server.listen(port, () => console.log(`Mock UI listening on http://localhost:${port}`));

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));