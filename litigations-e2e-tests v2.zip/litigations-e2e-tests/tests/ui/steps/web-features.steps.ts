import { When, Then, Given } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CasesPage } from '../support/CasesPage';
import { DocumentsPage } from '../support/DocumentsPage';
import { HearingsPage } from '../support/HearingsPage';

// Cases Steps
When('eu acesso a página de casos', async function () {
  this.casesPage = new CasesPage(this.page);
  await this.casesPage.goto();
});

Then('devo ver a lista de casos cadastrados', async function () {
  await expect(this.casesPage.casesTable).toBeVisible();
});

When('eu preencho o formulário de caso com título {string}, categoria {string} e prioridade {string}', async function (titulo: string, categoria: string, prioridade: string) {
  await this.casesPage.fillCaseForm(titulo, categoria, prioridade);
});

Then('o caso {string} deve aparecer na lista', async function (caseTitle: string) {
  await this.page.waitForTimeout(1000); // Wait for table to refresh
  const isVisible = await this.casesPage.isCaseInTable(caseTitle);
  expect(isVisible).toBeTruthy();
});

Given('que existe um caso {string} na lista', async function (caseTitle: string) {
  // Create the case through the API to ensure it exists
  const caseData = {
    title: caseTitle,
    description: `Descrição do caso ${caseTitle}`,
    category: 'civil',
    priority: 'medium'
  };
  
  try {
    const response = await fetch('http://localhost:3333/litigation/cases', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(caseData)
    });
    if (!response.ok) {
      throw new Error(`Failed to create case: ${response.statusText}`);
    }
  } catch (error) {
    console.log('Error creating case:', error);
  }
  
  this.testCaseTitle = caseTitle;
});

When('eu clico em {string} para o caso {string}', async function (action: string, caseTitle: string) {
  if (action === 'Ver') {
    await this.casesPage.viewCase(caseTitle);
  } else if (action === 'Editar') {
    await this.casesPage.editCase(caseTitle);
  } else if (action === 'Excluir') {
    await this.casesPage.confirmAction();
    await this.casesPage.deleteCase(caseTitle);
  }
});

Then('devo ser redirecionado para a página de detalhes do caso', async function () {
  await this.page.waitForURL('**/case-details*');
});

When('eu altero a prioridade para {string}', async function (newPriority: string) {
  await this.casesPage.casePrioritySelect.selectOption(newPriority);
});

Then('o caso {string} não deve mais aparecer na lista', async function (caseTitle: string) {
  await this.page.waitForTimeout(1000); // Wait for table to refresh
  const isVisible = await this.casesPage.isCaseInTable(caseTitle);
  expect(isVisible).toBeFalsy();
});

// Documents Steps
When('eu acesso a página de documentos', async function () {
  this.documentsPage = new DocumentsPage(this.page);
  await this.documentsPage.goto();
});

Then('devo ver a lista de documentos cadastrados', async function () {
  await expect(this.documentsPage.documentsTable).toBeVisible();
});

When('eu preencho o formulário de documento com nome {string}, tipo {string} e caso ID {string}', async function (nome: string, tipo: string, caseId: string) {
  await this.documentsPage.fillDocumentForm(nome, tipo, caseId);
});

Then('o documento {string} deve aparecer na lista', async function (docName: string) {
  await this.page.waitForTimeout(1000); // Wait for table to refresh
  const isVisible = await this.documentsPage.isDocumentInTable(docName);
  expect(isVisible).toBeTruthy();
});

Given('que existe um documento {string} na lista', async function (docName: string) {
  // Create the document through the API to ensure it exists
  const documentData = {
    name: docName,
    type: 'contract',
    caseId: 1
  };
  
  try {
    const response = await fetch('http://localhost:3333/documents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(documentData)
    });
    if (!response.ok) {
      throw new Error(`Failed to create document: ${response.statusText}`);
    }
  } catch (error) {
    console.log('Error creating document:', error);
  }
  
  this.testDocName = docName;
});

When('eu clico em {string} para o documento {string}', async function (action: string, docName: string) {
  if (action === 'Download') {
    await this.documentsPage.downloadDocument(docName);
  } else if (action === 'Excluir') {
    await this.documentsPage.deleteDocument(docName);
  }
});

// Step definition removed to avoid duplication - using the one in web-management.steps.ts

Then('o documento {string} não deve mais aparecer na lista', async function (docName: string) {
  await this.page.waitForTimeout(1000); // Wait for table to refresh
  const isVisible = await this.documentsPage.isDocumentInTable(docName);
  expect(isVisible).toBeFalsy();
});

// Hearings Steps
When('eu acesso a página de audiências', async function () {
  this.hearingsPage = new HearingsPage(this.page);
  await this.hearingsPage.goto();
});

Then('devo ver a lista de audiências agendadas', async function () {
  await expect(this.hearingsPage.hearingsTable).toBeVisible();
});

When('eu preencho o formulário de audiência com tipo {string}, data {string}, horário {string}, local {string} e caso ID {string}', async function (tipo: string, data: string, horario: string, local: string, caseId: string) {
  await this.hearingsPage.fillHearingForm(tipo, data, horario, local, caseId);
});

When('eu clico em agendar', async function () {
  const button = this.page.getByText('Agendar').first();
  await button.click();
});

Then('a audiência deve aparecer na lista com status {string}', async function (expectedStatus: string) {
  await this.page.waitForTimeout(1000); // Wait for table to refresh
  // We'll check if the table has updated - in a real scenario we'd check specific status
  await expect(this.hearingsPage.hearingsTable).toBeVisible();
});

Given('que existe uma audiência {string} agendada', async function (hearingType: string) {
  this.testHearingType = hearingType;
});

When('eu clico em {string} para a audiência', async function (action: string) {
  if (action === 'Cancelar') {
    await this.hearingsPage.confirmAction();
    await this.hearingsPage.cancelHearing(this.testHearingType || 'initial');
  }
});

When('eu confirmo o cancelamento', async function () {
  // Dialog handler is set in the page object
  await this.page.waitForTimeout(500);
});

Then('a audiência deve ter status {string}', async function (expectedStatus: string) {
  await this.page.waitForTimeout(1000); // Wait for status update
  // In a real implementation, we'd check the actual status in the table
  await expect(this.hearingsPage.hearingsTable).toBeVisible();
});

// Navigation Steps
When('eu clico no link {string} na navegação', async function (linkText: string) {
  await this.hearingsPage.navigateTo(linkText);
});

Then('devo ser redirecionado para o dashboard', async function () {
  await this.page.waitForURL('**/dashboard');
});

Then('devo ser redirecionado para a página de usuários', async function () {
  await this.page.waitForURL('**/users');
});

Then('devo ser redirecionado para a página de casos', async function () {
  await this.page.waitForURL('**/cases');
});

Then('devo ser redirecionado para a página de documentos', async function () {
  await this.page.waitForURL('**/documents');
});