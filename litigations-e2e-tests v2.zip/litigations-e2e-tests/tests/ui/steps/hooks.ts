import {
  Before,
  After,
  BeforeAll,
  AfterAll,
  setWorldConstructor
} from '@cucumber/cucumber';

import {
  chromium,
  Browser,
  BrowserContext,
  Page
} from '@playwright/test';

/**
 * Custom World for UI Tests
 */
class UIWorld {
  browser!: Browser;
  context!: BrowserContext;
  page!: Page;
}

setWorldConstructor(UIWorld as any);

/**
 * Recursos compartilhados por WORKER (UI)
 */
let sharedBrowser: Browser;

/**
 * Executa UMA VEZ por worker
 */
BeforeAll(async () => {
  sharedBrowser = await chromium.launch({
    headless: true, // CI-safe
    args: ['--disable-dev-shm-usage'] // evita crash no Linux do Azure
  });
});

/**
 * Executa ANTES de cada cenário UI
 */
Before(async function () {
  this.browser = sharedBrowser;
  this.context = await this.browser.newContext();

  // Tracing só em CI (opcional)
  if (process.env.CI === 'true') {
    await this.context.tracing.start({
      screenshots: true,
      snapshots: true
    });
  }

  this.page = await this.context.newPage();
  
  // Listen to console events
  this.page.on('console', (msg: any) => {
    console.log('PAGE LOG:', msg.text());
  });
  
  // Listen to page errors
  this.page.on('pageerror', (error: any) => {
    console.log('PAGE ERROR:', error.message);
  });
});

/**
 * Executa DEPOIS de cada cenário UI
 */
After(async function ({ result }) {
  // Screenshot + trace SOMENTE se falhar
  if (result?.status === 'FAILED' && this.page) {
    const fs = require('fs');
    fs.mkdirSync('allure-results', { recursive: true });

    // Screenshot
    const screenshot = await this.page.screenshot({ fullPage: true });
    fs.writeFileSync(
      `allure-results/screenshot-${Date.now()}.png`,
      screenshot
    );

    // Trace
    if (process.env.CI === 'true') {
      await this.context.tracing.stop({
        path: `allure-results/trace-${Date.now()}.zip`
      });
    }
  } else {
    // Para cenários OK, apenas parar o tracing
    if (process.env.CI === 'true') {
      await this.context.tracing.stop();
    }
  }

  await this.page.close();
  await this.context.close();
});

/**
 * Executa UMA VEZ por worker (final)
 */
AfterAll(async () => {
  await sharedBrowser.close();
});