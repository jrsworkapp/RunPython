# Contributing

Este projeto segue convenções simples inspiradas em grandes times de engenharia para manter consistência e facilitar contribuições.

1) Código e organização
- Tests (Cucumber + Playwright): `tests/`
- Page objects compartilhados com os testes: `tests/support/pages/`
- Código reutilizável: `src/` (helpers de API, utilitários)

2) Rodando localmente
- Instale dependências:
```bash
npm install
```
- Inicie mocks (em terminais separados) ou use o script que os gerencia:
```bash
npm run start:mocks
# em outro terminal, se preferir manualmente
npm run mock:api
npm run mock:ui
```
- Rodar testes:
```bash
npm run test:cucumber
npm run test:playwright
npm run test:all   # inicia mocks, roda Cucumber + Playwright, e para mocks
```

3) Variáveis de ambiente úteis
- `HEADLESS`: `true|false` — controla modo headless para browsers.
- `CI`: `true|false` — força `HEADLESS=true` quando em pipelines.
- `API_BASE_URL`, `BASE_URL` — substituir endpoints dos mocks por serviços reais quando necessário.

4) Branching & Commits
- Use branches com nomes descritivos: `feature/<descrição>`, `fix/<descrição>`, `chore/<descrição>`.
- Mensagens de commit: `tipo: descrição` (e.g. `feat: add login flow test`).

5) Pull Requests
- Faça PRs pequenos e focados; inclua descrição do que foi feito, comando para reproduzir localmente e screenshots/logs se relevante.

6) CI
- Este repositório inclui um workflow GitHub Actions que executa TypeScript, inicia mocks e roda os testes. Ver `/.github/workflows/ci.yml`.

7) Lint & formatação
- Recomendamos configurar ESLint e Prettier como próximos passos; não estão instalados automaticamente neste repositório.

Se precisar, posso adicionar ESLint/Prettier e hooks de pre-commit (husky) automaticamente.
