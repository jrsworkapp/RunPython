module.exports = {
  default: {
    require: ['ts-node/register', 'src/**/steps/**/*.ts'],
    format: ['progress', '@cucumber/pretty-formatter'],
    publishQuiet: true,
    paths: ['src/**/features/**/*.feature'],
    parallel: 2,
    worldParameters: {
      apiBaseUrl: 'http://localhost:3333'
    }
  }
};
