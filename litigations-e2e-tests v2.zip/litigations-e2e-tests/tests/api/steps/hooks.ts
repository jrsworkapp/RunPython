import {
  Before,
  After,
  BeforeAll,
  AfterAll,
  setWorldConstructor
} from '@cucumber/cucumber';

import { request, APIRequestContext } from '@playwright/test';

/**
 * Custom World for API Tests
 */
class APIWorld {
  apiRequest!: APIRequestContext;
}

setWorldConstructor(APIWorld as any);

/**
 * Recursos compartilhados por WORKER (API)
 */
let sharedApiRequest: APIRequestContext;

/**
 * Executa UMA VEZ por worker
 */
BeforeAll(async () => {
  sharedApiRequest = await request.newContext({
    baseURL: process.env.API_BASE_URL || 'http://localhost:3333'
  });
});

/**
 * Executa ANTES de cada cenário API
 */
Before(async function () {
  this.apiRequest = sharedApiRequest;
});

/**
 * Executa DEPOIS de cada cenário API
 */
After(async function ({ result }) {
  // Log de falha para testes de API se necessário
  if (result?.status === 'FAILED') {
    console.error(`API Test failed: ${result.message}`);
  }
});

/**
 * Executa UMA VEZ por worker (final)
 */
AfterAll(async () => {
  if (sharedApiRequest) {
    await sharedApiRequest.dispose();
  }
});