import { When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';

let lastResponse: any;

When('eu faço GET em {string}', async function (path: string) {
  // Use shared apiRequest from World when available, otherwise create a short-lived context
  if (this.apiRequest) {
    lastResponse = await this.apiRequest.get(path);
  } else {
    const { request } = await import('@playwright/test');
    const api = await request.newContext({ baseURL: 'http://localhost:3333' });
    lastResponse = await api.get(path);
    await api.dispose();
  }
});

Then('o status da resposta deve ser {int}', async function (status: number) {
  expect(lastResponse.status()).toBe(status);
});

Then('o corpo deve conter ao menos 1 usuário', async function () {
  const body = await lastResponse.json();
  expect(body.length).toBeGreaterThan(0);
});
