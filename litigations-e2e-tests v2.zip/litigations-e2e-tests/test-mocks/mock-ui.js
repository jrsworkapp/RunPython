// test-mocks/mock-ui.js
const http = require('http');

// Simulate session state
let isAuthenticated = false;
let currentUser = null;

const commonStyles = `
  @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap');
  @import url('https://unpkg.com/lucide@latest/dist/umd/lucide.js');
  
  :root {
    /* Paleta Natura - Cores Naturais */
    --natura-orange: #FF6900;
    --natura-orange-light: #FFF4ED;
    --natura-orange-dark: #E55A00;
    --natura-green: #00A859;
    --natura-green-light: #E8F5E8;
    --natura-green-dark: #008A48;
    --natura-brown: #8B4513;
    --natura-brown-light: #F5E6D3;
    --natura-cream: #FDF6E3;
    --natura-sage: #9CAF88;
    --natura-sage-light: #F0F4EC;
    --natura-earth: #D2B48C;
    --natura-earth-light: #F9F5F0;
    
    /* Tons Neutros Naturais */
    --natura-white: #FFFFFF;
    --natura-off-white: #FEFCF9;
    --natura-gray-50: #F9F7F4;
    --natura-gray-100: #F1EDE6;
    --natura-gray-200: #E8E1D6;
    --natura-gray-300: #D1C7B8;
    --natura-gray-400: #A8998A;
    --natura-gray-500: #806F5E;
    --natura-gray-600: #5D4E3F;
    --natura-gray-700: #3D332A;
    --natura-gray-800: #2A1F17;
    --natura-gray-900: #1C140E;
    
    /* Sombras Sutis - Material Design 3 Elevation */
    --natura-shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
    --natura-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
    --natura-shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --natura-shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --natura-shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  }
  
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
  body {
    font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: var(--natura-off-white);
    color: var(--natura-gray-800);
    line-height: 1.6;
    font-weight: 400;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }
  
  /* Design Natura - App Container */
  .app-container {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    background: var(--natura-off-white);
  }
  
  /* Navbar Natura - Design Orgânico */
  .navbar {
    background: var(--natura-white);
    color: var(--natura-gray-700);
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
    position: sticky;
    top: 0;
    z-index: 1000;
    border-bottom: 1px solid rgba(255, 105, 0, 0.15);
  }
  
  .navbar-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    min-height: 70px;
  }
  
  .navbar-brand {
    color: var(--natura-orange);
    font-size: 1.5rem;
    font-weight: 800;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 12px;
    transition: all 0.3s ease;
  }
  
  .navbar-brand:hover {
    color: var(--natura-orange-dark);
    transform: translateX(2px);
  }
  
  .navbar-brand .icon {
    width: 28px;
    height: 28px;
    stroke-width: 2.5;
    color: var(--natura-orange);
  }
  
  /* Navigation Natura - Design Natural */
  .tab-navigation {
    display: flex;
    gap: 8px;
  }
  
  .tab-link {
    color: var(--natura-gray-600);
    text-decoration: none;
    padding: 12px 18px;
    border-radius: 25px;
    font-size: 0.95rem;
    font-weight: 600;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
    position: relative;
    background: var(--natura-gray-50);
  }
  
  .tab-link:hover {
    color: var(--natura-orange);
    background: var(--natura-orange-light);
    transform: translateY(-2px);
    box-shadow: var(--natura-shadow-sm);
  }
  
  .tab-link.active {
    color: var(--natura-white);
    background: var(--natura-orange);
    box-shadow: var(--natura-shadow);
  }
  
  .tab-link.active:hover {
    background: var(--natura-orange-dark);
    transform: translateY(-2px);
  }
  
  .tab-link .tab-icon {
    width: 18px;
    height: 18px;
    stroke-width: 2.5;
    flex-shrink: 0;
  }
  
  .user-menu {
    display: flex;
    align-items: center;
    gap: 16px;
  }
  
  .user-info {
    color: var(--natura-gray-600);
    font-size: 0.875rem;
    font-weight: 600;
  }
  
  .logout-btn {
    background: var(--natura-gray-100);
    color: var(--natura-gray-700);
    border: 1.5px solid var(--natura-gray-300);
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 0.875rem;
    font-weight: 600;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  
  .logout-btn:hover {
    background: var(--natura-gray-200);
    border-color: var(--natura-gray-400);
    color: var(--natura-gray-800);
    transform: translateY(-2px);
    box-shadow: var(--natura-shadow-sm);
  }
  
  /* Natura Main Content */
  .main-content {
    flex: 1;
    max-width: 1200px;
    margin: 0 auto;
    padding: 40px 24px;
    width: 100%;
    background: var(--natura-off-white);
  }
  
  .page-header {
    text-align: center;
    margin-bottom: 40px;
  }
  
  .page-title {
    font-size: 2.5rem;
    font-weight: 800;
    color: var(--natura-gray-800);
    margin-bottom: 12px;
    letter-spacing: -0.5px;
  }
  
  .page-subtitle {
    color: var(--natura-gray-600);
    font-size: 1.125rem;
    line-height: 1.6;
    font-weight: 400;
  }
  
  /* Natura Cards com Sombras Suaves */
  .cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 24px;
    margin-top: 32px;
  }
  
  .card {
    background: var(--natura-white);
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
    border: 1px solid rgba(0, 0, 0, 0.05);
    transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    color: var(--natura-gray-800);
    position: relative;
  }
  
  .card:hover {
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    transform: translateY(-2px);
    border-color: rgba(255, 105, 0, 0.15);
  }
  
  .card-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 16px;
  }
  
  .card-icon {
    width: 48px;
    height: 48px;
    background: linear-gradient(135deg, var(--natura-orange-light) 0%, rgba(255, 105, 0, 0.08) 100%);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--natura-orange);
    box-shadow: 0 2px 4px 0 rgba(255, 105, 0, 0.1);
  }
  
  .card-icon svg,
  .card-icon i {
    width: 24px;
    height: 24px;
    stroke-width: 2;
  }
  
  .card-title {
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--natura-gray-800);
    margin: 0;
  }
  
  .card-description {
    color: var(--natura-gray-600);
    font-size: 0.9375rem;
    margin-bottom: 20px;
    line-height: 1.6;
  }
  
  /* Natura Buttons - Sistema Completo */
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-family: 'Nunito', sans-serif;
    font-size: 0.9375rem;
    font-weight: 600;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
    text-decoration: none;
    min-height: 44px;
    box-sizing: border-box;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  
  /* Ripple Effect */
  .btn::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.5);
    transform: translate(-50%, -50%);
    transition: width 0.6s, height 0.6s;
  }
  
  .btn:active::after {
    width: 300px;
    height: 300px;
  }
  
  /* Primary Button */
  .btn-primary {
    background: var(--natura-orange);
    color: var(--natura-white);
    box-shadow: 0 2px 4px rgba(255, 105, 0, 0.3);
  }
  
  .btn-primary:hover {
    background: var(--natura-orange-dark);
    box-shadow: 0 4px 12px rgba(255, 105, 0, 0.4);
    transform: translateY(-2px);
  }
  
  .btn-primary:active {
    transform: translateY(0);
    box-shadow: 0 2px 4px rgba(255, 105, 0, 0.3);
  }
  
  /* Secondary Button */
  .btn-secondary {
    background: transparent;
    color: var(--natura-orange);
    border: 2px solid var(--natura-orange);
    box-shadow: none;
  }
  
  .btn-secondary:hover {
    background: var(--natura-orange-light);
    border-color: var(--natura-orange-dark);
    color: var(--natura-orange-dark);
    box-shadow: 0 2px 8px rgba(255, 105, 0, 0.2);
  }
  
  /* Outlined Button */
  .btn-outlined {
    background: transparent;
    color: var(--natura-gray-700);
    border: 1.5px solid var(--natura-gray-400);
    box-shadow: none;
  }
  
  .btn-outlined:hover {
    background: var(--natura-gray-100);
    border-color: var(--natura-gray-600);
    color: var(--natura-gray-800);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  }
  
  /* Danger Button */
  .btn-danger {
    background: #DC2626;
    color: var(--natura-white);
    box-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
  }
  
  .btn-danger:hover {
    background: #B91C1C;
    box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4);
    transform: translateY(-2px);
  }
  
  /* Small Buttons */
  .btn-sm {
    padding: 8px 16px;
    min-height: 36px;
    border-radius: 6px;
    font-size: 0.8125rem;
    gap: 6px;
    margin-right: 8px;
    text-transform: none;
    letter-spacing: 0.3px;
  }
  
  .btn svg {
    width: 18px;
    height: 18px;
    stroke-width: 2.5;
    flex-shrink: 0;
  }
  
  .btn-sm svg {
    width: 16px;
    height: 16px;
  }
  
  /* Action Button (Variante do Primary) */
  .btn-action {
    background: var(--natura-green);
    color: var(--natura-white);
    box-shadow: 0 2px 4px rgba(0, 168, 89, 0.3);
  }
  
  .btn-action:hover {
    background: var(--natura-green-dark);
    box-shadow: 0 4px 12px rgba(0, 168, 89, 0.4);
    transform: translateY(-2px);
  }
  
  /* Outline variant */
  .btn-outline {
    background: transparent;
    color: var(--natura-gray-700);
    border: 1.5px solid var(--natura-gray-300);
  }
  
  .btn-outline:hover {
    background: var(--natura-gray-50);
    border-color: var(--natura-gray-500);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  }
  
  /* Natura Tables */
  .table-container {
    background: var(--apple-white);
    border-radius: 18px;
    overflow: hidden;
    box-shadow: var(--apple-shadow-medium);
    border: 0.5px solid rgba(0,0,0,0.04);
    position: relative;
  }
  
  .table-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.8), transparent);
    z-index: 1;
  }
  
  .table {
    width: 100%;
    border-collapse: collapse;
  }
  
  .table th {
    background: var(--apple-gray-2);
    padding: 20px 24px;
    text-align: left;
    font-size: var(--text-sm);
    font-weight: 600;
    color: var(--apple-gray-7);
    border-bottom: 0.5px solid var(--apple-gray-3);
    letter-spacing: -0.016em;
    line-height: 1.4285714286;
  }
  
  .table td {
    padding: 20px 24px;
    border-bottom: 0.5px solid var(--apple-gray-3);
    font-size: var(--text-base);
    color: var(--apple-gray-8);
    letter-spacing: -0.022em;
    line-height: 1.4211026316;
  }
  
  .table tbody tr {
    transition: background-color 0.25s cubic-bezier(0.4, 0, 0.6, 1);
  }
  
  .table tbody tr:hover {
    background: rgba(0,113,227,0.04);
  }
  
  .table tbody tr:last-child td {
    border-bottom: none;
  }
  
  /* Natura Forms */
  .form-group {
    margin-bottom: 20px;
  }
  
  .form-label {
    display: block;
    margin-bottom: 8px;
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--natura-gray-700);
  }
  
  .form-input, .form-select, textarea.form-input {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid rgba(0, 0, 0, 0.12);
    border-radius: 8px;
    font-size: 0.9375rem;
    font-family: 'Nunito', sans-serif;
    background: var(--natura-white);
    color: var(--natura-gray-800);
    transition: all 0.2s ease;
    box-sizing: border-box;
  }
  
  .form-input:focus, .form-select:focus, textarea.form-input:focus {
    outline: none;
    border-color: var(--natura-orange);
    box-shadow: 0 0 0 3px rgba(255, 105, 0, 0.1);
  }
  
  .form-input::placeholder {
    color: var(--natura-gray-500);
  }
  
  /* Natura Modals */
  .modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(28, 20, 14, 0.5);
    backdrop-filter: blur(4px);
    animation: modalFadeIn 0.3s ease;
  }
  
  .modal.show {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
  }
  
  .modal-content {
    background: var(--natura-white);
    border-radius: 16px;
    width: 100%;
    max-width: 540px;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    border: none;
    animation: modalSlideIn 0.3s ease;
    padding: 32px;
  }
  
  @keyframes modalFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  
  @keyframes modalSlideIn {
    from { transform: scale(0.95) translateY(20px); opacity: 0; }
    to { transform: scale(1) translateY(0); opacity: 1; }
  }
  
  .modal-content h3 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--natura-gray-800);
    margin: 0 0 24px 0;
    padding-bottom: 16px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.08);
  }
  
  .modal-close {
    position: absolute;
    top: 20px;
    right: 20px;
    background: var(--natura-gray-100);
    border: none;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    cursor: pointer;
    color: var(--natura-gray-600);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    font-size: 1.5rem;
    line-height: 1;
  }
  
  .modal-close:hover {
    background: var(--natura-gray-200);
    color: var(--natura-gray-800);
    transform: rotate(90deg);
  }
  
  /* Natura Messages & Status Badges */
  .message {
    padding: 14px 18px;
    border-radius: 8px;
    margin-bottom: 16px;
    font-size: 0.9375rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  
  .message.success {
    background: var(--natura-green-light);
    color: var(--natura-green-dark);
    border: 1.5px solid var(--natura-green);
  }
  
  .message.error {
    background: rgba(220, 38, 38, 0.1);
    color: #B91C1C;
    border: 1.5px solid #DC2626;
  }
  
  /* Status Badges */
  .status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  
  .status-badge.active {
    background: var(--natura-green-light);
    color: var(--natura-green-dark);
  }
  
  .status-badge.inactive {
    background: var(--natura-gray-200);
    color: var(--natura-gray-600);
  }
  
  .status-badge.pending {
    background: #FEF3C7;
    color: #D97706;
  }
  
  /* Priority Badges */
  .priority {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }
  
  .priority.high {
    background: rgba(220, 38, 38, 0.15);
    color: #DC2626;
  }
  
  .priority.medium {
    background: #FEF3C7;
    color: #D97706;
  }
  
  .priority.low {
    background: var(--natura-green-light);
    color: var(--natura-green-dark);
  }
  
  /* Utilities */
  .flex { display: flex; }
  .items-center { align-items: center; }
  .justify-between { justify-content: space-between; }
  .gap-2 { gap: 8px; }
  .gap-4 { gap: 16px; }
  .gap-6 { gap: 24px; }
  .mb-4 { margin-bottom: 16px; }
  .mb-6 { margin-bottom: 24px; }
  .mt-4 { margin-top: 16px; }
  .mt-6 { margin-top: 24px; }
  .p-4 { padding: 16px; }
  .p-6 { padding: 24px; }
  
  /* Natura Responsive */
  @media (max-width: 1024px) {
    .navbar-container {
      padding: 0 20px;
    }
    
    .main-content {
      padding: 32px 20px;
    }
    
    .page-title {
      font-size: 2rem;
    }
  }
  
  @media (max-width: 768px) {
    .navbar-container {
      padding: 0 16px;
    }
    
    .tab-navigation {
      display: none;
    }
    
    .user-info {
      display: none;
    }
    
    .cards-grid {
      grid-template-columns: 1fr;
      gap: 20px;
    }
    
    .main-content {
      padding: 24px 16px;
    }
    
    .page-title {
      font-size: 1.75rem;
    }
    
    .page-subtitle {
      font-size: 1rem;
    }
    
    .modal-content {
      padding: 24px;
      max-height: 95vh;
    }
    
    .card {
      padding: 24px 20px;
    }
    
    .table th, .table td {
      padding: 12px;
      font-size: 0.875rem;
    }
  }
  
  @media (max-width: 480px) {
    .page-title {
      font-size: 1.5rem;
    }
    
    .card {
      padding: 20px 16px;
    }
    
    .modal-content {
      padding: 20px;
    }
  }
`;

const loginPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Login - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <style>
      :root {
        /* Paleta Natura - Cores Naturais */
        --natura-orange: #FF6900;
        --natura-orange-light: #FFF4ED;
        --natura-orange-dark: #E55A00;
        --natura-green: #00A859;
        --natura-green-light: #E8F5E8;
        --natura-green-dark: #008A48;
        
        /* Tons Neutros Naturais */
        --natura-white: #FFFFFF;
        --natura-off-white: #FEFCF9;
        --natura-gray-50: #F9F7F4;
        --natura-gray-100: #F1EDE6;
        --natura-gray-200: #E8E1D6;
        --natura-gray-300: #D1C7B8;
        --natura-gray-400: #A8998A;
        --natura-gray-500: #806F5E;
        --natura-gray-600: #5D4E3F;
        --natura-gray-700: #3D332A;
        --natura-gray-800: #2A1F17;
        
        /* Sombras Naturais */
        --natura-shadow-sm: 0 1px 3px rgba(45, 35, 25, 0.08);
        --natura-shadow: 0 2px 8px rgba(45, 35, 25, 0.12);
        --natura-shadow-lg: 0 8px 25px rgba(45, 35, 25, 0.15);
        --natura-shadow-xl: 0 15px 35px rgba(45, 35, 25, 0.18);
      }
      
      html,body,#root{
        height:100%;
        margin:0;
        font-family:'Nunito', -apple-system, BlinkMacSystemFont, sans-serif;
        background: var(--natura-off-white);
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
      
      .login-container{
        display:flex;
        justify-content:center;
        align-items:center;
        min-height:100vh;
        padding: 20px;
        background: var(--natura-off-white);
      }
      
      .login-form{
        background: var(--natura-white);
        padding: 48px 40px;
        border-radius: 16px;
        box-shadow: var(--natura-shadow-lg);
        max-width: 400px;
        width: 100%;
        border: 1px solid var(--natura-gray-200);
      }
      
      .form-header {
        text-align: center;
        margin-bottom: 32px;
      }
      
      .form-icon {
        width: 48px;
        height: 48px;
        background: var(--natura-orange);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        color: white;
      }
      
      .form-title{
        color: var(--natura-gray-800);
        margin: 0;
        font-size: 1.5rem;
        font-weight: 700;
        letter-spacing: -0.02em;
      }
      
      .form-subtitle {
        color: var(--natura-gray-600);
        font-size: 0.9375rem;
        margin-top: 8px;
        font-weight: 400;
      }
      
      .form-group{
        margin-bottom: 20px;
      }
      
      .form-label{
        display: block;
        margin-bottom: 8px;
        font-size: 0.875rem;
        font-weight: 600;
        color: var(--natura-gray-700);
      }
      
      .form-input{
        width: 100%;
        padding: 14px 16px;
        border: 1.5px solid var(--natura-gray-300);
        border-radius: 8px;
        font-size: 0.9375rem;
        font-family: 'Nunito', sans-serif;
        background: var(--natura-white);
        color: var(--natura-gray-800);
        transition: all 0.2s ease;
        box-sizing: border-box;
      }
      
      .form-input:focus{
        outline: none;
        border-color: var(--natura-orange);
        box-shadow: 0 0 0 3px var(--natura-orange-light);
      }
      
      .form-input::placeholder {
        color: var(--natura-gray-500);
      }
      
      .login-button{
        width: 100%;
        background: var(--natura-orange);
        color: var(--natura-white);
        padding: 14px 24px;
        border: none;
        border-radius: 8px;
        font-size: 0.9375rem;
        font-weight: 600;
        font-family: 'Nunito', sans-serif;
        cursor: pointer;
        transition: all 0.2s ease;
        box-shadow: 0 2px 4px rgba(255, 105, 0, 0.3);
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }
      
      .login-button:hover{
        background: var(--natura-orange-dark);
        box-shadow: 0 4px 12px rgba(255, 105, 0, 0.4);
        transform: translateY(-2px);
      }
      
      .login-button:active {
        transform: translateY(0);
      }
      
      .error-message, .success-message{
        font-size: 0.9375rem;
        margin-top: 16px;
        text-align: center;
        padding: 12px 16px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        letter-spacing: -0.01em;
      }
      
      .error-message{
        background: rgba(255, 59, 48, 0.1);
        color: #c41e3a;
        border: 1px solid rgba(255, 59, 48, 0.2);
      }
      
      .success-message{
        background: rgba(52, 199, 89, 0.1);
        color: #1b7e3a;
        border: 1px solid rgba(52, 199, 89, 0.2);
      }
      
      @media (max-width: 480px) {
        .login-form {
          padding: 32px 24px;
        }
      }
    </style>
  </head>
  <body>
    <div id="root" class="login-container">
      <div class="login-form">
        <div class="form-header">
          <div class="form-icon">
            <i data-lucide="scale"></i>
          </div>
          <h2 class="form-title">Sistema Jurídico</h2>
          <p class="form-subtitle">Entre com suas credenciais</p>
        </div>
        <form>
          <div class="form-group">
            <label class="form-label" for="username">E-mail</label>
            <input type="email" class="form-input" id="username" name="username" placeholder="Digite seu e-mail" />
          </div>
          <div class="form-group">
            <label class="form-label" for="password">Senha</label>
            <input type="password" class="form-input" id="password" name="password" placeholder="Digite sua senha" />
          </div>
          <button type="button" class="login-button" onclick="performLogin()">
            <i data-lucide="log-in"></i>
            Entrar
          </button>
          <div class="error-message" id="error-message" style="display: none;">
            <i data-lucide="alert-circle"></i>
            <span id="error-text"></span>
          </div>
          <div class="success-message" id="success-message" style="display: none;">
            <i data-lucide="check-circle"></i>
            <span>Login realizado com sucesso!</span>
          </div>
        </form>
      </div>
    </div>

    <script>
      // Initialize Lucide icons
      lucide.createIcons();
    
      function performLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorMsg = document.getElementById('error-message');
        const successMsg = document.getElementById('success-message');
        const errorText = document.getElementById('error-text');

        errorMsg.style.display = 'none';
        successMsg.style.display = 'none';

        if (!username || !password) {
          errorText.textContent = 'Por favor, preencha todos os campos';
          errorMsg.style.display = 'flex';
          return;
        }

        if (username === 'user@test.com' && password === '123456') {
          successMsg.style.display = 'flex';
          setTimeout(() => {
            window.location.href = '/dashboard';
          }, 1000);
        } else {
          errorText.textContent = 'Credenciais inválidas';
          errorMsg.style.display = 'flex';
        }
      }

      // Handle Enter key
      document.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
          performLogin();
        }
      });
    </script>
  </body>
</html>
`;

const dashboardPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Dashboard - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">
            <i data-lucide="scale" class="icon"></i>
            Sistema Jurídico
          </a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link active">
              <i data-lucide="layout-dashboard"></i>
              Dashboard
            </a>
            <a href="/users" class="tab-link">
              <i data-lucide="users"></i>
              Usuários
            </a>
            <a href="/cases" class="tab-link">
              <i data-lucide="briefcase"></i>
              Casos
            </a>
            <a href="/documents" class="tab-link">
              <i data-lucide="file-text"></i>
              Documentos
            </a>
            <a href="/hearings" class="tab-link">
              <i data-lucide="calendar"></i>
              Audiências
            </a>
          </div>
          <div class="user-menu">
            <span class="user-info">
              <i data-lucide="user"></i>
              user@test.com
            </span>
            <button class="logout-btn" onclick="logout()">
              <i data-lucide="log-out"></i>
              Sair
            </button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Dashboard</h1>
          <p class="page-subtitle">Visão geral do sistema jurídico</p>
        </div>
        
        <div class="cards-grid">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">
                <i data-lucide="users"></i>
              </div>
              <div class="card-title">Usuários</div>
            </div>
            <p class="card-description">Gerencie usuários do sistema, adicione novos advogados e funcionários</p>
            <a href="/users" class="btn btn-primary">
              <i data-lucide="arrow-right"></i>
              Gerenciar Usuários
            </a>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">
                <i data-lucide="briefcase"></i>
              </div>
              <div class="card-title">Casos Jurídicos</div>
            </div>
            <p class="card-description">Acompanhe processos judiciais, gerencie prazos e documentação</p>
            <a href="/cases" class="btn btn-primary">
              <i data-lucide="arrow-right"></i>
              Ver Casos
            </a>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">
                <i data-lucide="file-text"></i>
              </div>
              <div class="card-title">Documentos</div>
            </div>
            <p class="card-description">Organize documentos legais, contratos e petições do escritório</p>
            <a href="/documents" class="btn btn-primary">
              <i data-lucide="arrow-right"></i>
              Gerenciar Documentos
            </a>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">
                <i data-lucide="calendar"></i>
              </div>
              <div class="card-title">Audiências</div>
            </div>
            <p class="card-description">Agende audiências, gerencie calendário e notificações</p>
            <a href="/hearings" class="btn btn-primary">
              <i data-lucide="arrow-right"></i>
              Ver Audiências
            </a>
          </div>
        </div>
        
        <div class="cards-grid mt-6">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">
                <i data-lucide="bar-chart-3"></i>
              </div>
              <div class="card-title">Estatísticas do Mês</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: var(--natura-orange);">24</div>
                <div style="font-size: 0.875rem; color: var(--natura-gray-600);">Casos Ativos</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">12</div>
                <div style="font-size: 0.875rem; color: var(--natura-gray-600);">Audiências</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">156</div>
                <div style="font-size: 0.875rem; color: var(--natura-gray-600);">Documentos</div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">
                <i data-lucide="clock"></i>
              </div>
              <div class="card-title">Próximas Atividades</div>
            </div>
            <div style="font-size: 0.875rem; color: var(--natura-gray-600); line-height: 1.6;">
              <div style="margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                <i data-lucide="calendar" style="width: 16px; height: 16px;"></i>
                <span>Audiência - Caso Silva vs. Santos - 15/01/2026</span>
              </div>
              <div style="margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                <i data-lucide="clock" style="width: 16px; height: 16px;"></i>
                <span>Prazo para contestação - Caso Oliveira - 18/01/2026</span>
              </div>
              <div style="margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                <i data-lucide="users" style="width: 16px; height: 16px;"></i>
                <span>Reunião com cliente - Maria Costa - 20/01/2026</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <script>
      // Initialize Lucide icons
      lucide.createIcons();
      
      function logout() {
        if (confirm('Tem certeza que deseja sair?')) {
          window.location.href = '/login';
        }
      }
    </script>
  </body>
</html>
`;

const usersPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Usuários - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">
            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"/>
              <path stroke-linecap="round" stroke-linejoin="round" d="M8 21v-4a2 2 0 012-2h4a2 2 0 012 2v4"/>
            </svg>
            Sistema Jurídico
          </a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7"/>
              </svg>
              Dashboard
            </a>
            <a href="/users" class="tab-link active">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
              </svg>
              Usuários
            </a>
            <a href="/cases" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              Casos
            </a>
            <a href="/documents" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              Documentos
            </a>
            <a href="/hearings" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 0V6a2 2 0 012-2h4a2 2 0 012 2v1m-6 0h8m-9 0a1 1 0 00-1 1v10a1 1 0 001 1h10a1 1 0 001-1V8a1 1 0 00-1-1H7z"/>
              </svg>
              Audiências
            </a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Gerenciamento de Usuários</h1>
          <p class="page-subtitle">Administre usuários, permissões e perfis do sistema</p>
          <button class="btn btn-primary" onclick="openUserModal()">+ Novo Usuário</button>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Lista de Usuários</div>
            <div class="search-container">
              <input type="text" id="userSearch" placeholder="Buscar usuários..." style="padding: 0.5rem; border: 1px solid #e1e5e9; border-radius: 0.375rem; font-size: 0.875rem;">
            </div>
          </div>
          
          <div id="message" style="display:none;padding:1rem;margin:1rem;border-radius:0.5rem;"></div>
          
          <div class="table-container">
            <table class="table" id="users-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nome</th>
                  <th>Email</th>
                  <th>Papel</th>
                  <th>Status</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="users-tbody">
                <tr>
                  <td>1</td>
                  <td>João Silva</td>
                  <td>joao.silva@escritorio.com</td>
                  <td><span class="status-badge active">Ativo</span></td>
                  <td>
                    <button class="btn-sm btn-outline">Editar</button>
                    <button class="btn-sm btn-danger">Excluir</button>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Maria Santos</td>
                  <td>maria.santos@escritorio.com</td>
                  <td><span class="status-badge active">Ativo</span></td>
                  <td>
                    <button class="btn-sm btn-outline">Editar</button>
                    <button class="btn-sm btn-danger">Excluir</button>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Pedro Costa</td>
                  <td>pedro.costa@escritorio.com</td>
                  <td><span class="status-badge inactive">Inativo</span></td>
                  <td>
                    <button class="btn-sm btn-secondary">Editar</button>
                    <button class="btn-sm btn-danger">Excluir</button>
                  </td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>Ana Oliveira</td>
                  <td>ana.oliveira@escritorio.com</td>
                  <td><span class="status-badge pending">Pendente</span></td>
                  <td>
                    <button class="btn-sm btn-secondary">Editar</button>
                    <button class="btn-sm btn-danger">Excluir</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📈</div>
              <div class="card-title">Estatísticas de Usuários</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">15</div>
                <div style="font-size: 0.875rem; color: #64748b;">Total de Usuários</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">12</div>
                <div style="font-size: 0.875rem; color: #64748b;">Usuários Ativos</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">3</div>
                <div style="font-size: 0.875rem; color: #64748b;">Pendentes</div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">👤</div>
              <div class="card-title">Perfis de Acesso</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Advogados</span>
                <span style="font-weight: 600;">8 usuários</span>
              </div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Secretárias</span>
                <span style="font-weight: 600;">4 usuários</span>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span>Administradores</span>
                <span style="font-weight: 600;">3 usuários</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- User Modal -->
    <div id="userModal" class="modal">
      <div class="modal-content">
        <span class="modal-close" onclick="closeUserModal()">&times;</span>
        <h3 id="modal-title">Adicionar Usuário</h3>
        <form id="userForm">
          <div class="form-group">
            <label class="form-label">Nome:</label>
            <input type="text" class="form-input" id="userName" required />
          </div>
          <div class="form-group">
            <label class="form-label">Email:</label>
            <input type="email" class="form-input" id="userEmail" required />
          </div>
          <div class="form-group">
            <label class="form-label">Papel:</label>
            <select class="form-input" id="userRole">
              <option value="user">Usuário</option>
              <option value="lawyer">Advogado</option>
              <option value="client">Cliente</option>
              <option value="admin">Administrador</option>
            </select>
          </div>
          <button type="submit" class="btn">Salvar</button>
          <button type="button" class="btn btn-danger" onclick="closeUserModal()">Cancelar</button>
        </form>
      </div>
    </div>

    <script>
      let users = [];
      let editingUserId = null;

      async function loadUsers() {
        try {
          const response = await fetch('http://localhost:3333/users');
          users = await response.json();
          renderUsers();
        } catch (error) {
          showMessage('Erro ao carregar usuários', 'error');
        }
      }

      function renderUsers() {
        const tbody = document.getElementById('users-tbody');
        tbody.innerHTML = users.map(user => 
          \`<tr>
            <td>\${user.id}</td>
            <td>\${user.name}</td>
            <td>\${user.email}</td>
            <td>\${user.role}</td>
            <td>\${user.active ? 'Ativo' : 'Inativo'}</td>
            <td>
              <button class="btn" onclick="editUser(\${user.id})">Editar</button>
              <button class="btn btn-danger" onclick="deleteUser(\${user.id})">Excluir</button>
            </td>
          </tr>\`
        ).join('');
      }

      function openUserModal(user = null) {
        const modal = document.getElementById('userModal');
        const title = document.getElementById('modal-title');
        
        if (user) {
          title.textContent = 'Editar Usuário';
          document.getElementById('userName').value = user.name;
          document.getElementById('userEmail').value = user.email;
          document.getElementById('userRole').value = user.role;
          editingUserId = user.id;
        } else {
          title.textContent = 'Adicionar Usuário';
          document.getElementById('userForm').reset();
          editingUserId = null;
        }
        
        modal.classList.add('show');
      }

      function closeUserModal() {
        document.getElementById('userModal').classList.remove('show');
      }

      function editUser(id) {
        const user = users.find(u => u.id === id);
        if (user) openUserModal(user);
      }

      async function deleteUser(id) {
        if (!confirm('Tem certeza que deseja excluir este usuário?')) return;
        
        try {
          await fetch('http://localhost:3333/users/' + id, { method: 'DELETE' });
          showMessage('Usuário excluído com sucesso', 'success');
          loadUsers();
        } catch (error) {
          showMessage('Erro ao excluir usuário', 'error');
        }
      }

      function showMessage(text, type) {
        const message = document.getElementById('message');
        message.textContent = text;
        message.className = type;
        message.style.display = 'block';
        setTimeout(() => message.style.display = 'none', 3000);
      }

      function logout() {
        window.location.href = '/login';
      }

      document.getElementById('userForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const userData = {
          name: document.getElementById('userName').value,
          email: document.getElementById('userEmail').value,
          role: document.getElementById('userRole').value
        };

        try {
          const url = editingUserId ? 
            'http://localhost:3333/users/' + editingUserId : 
            'http://localhost:3333/users';
          const method = editingUserId ? 'PUT' : 'POST';

          await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
          });

          showMessage(\`Usuário \${editingUserId ? 'atualizado' : 'criado'} com sucesso\`, 'success');
          closeUserModal();
          loadUsers();
        } catch (error) {
          showMessage('Erro ao salvar usuário', 'error');
        }
      });

      // Load users on page load
      loadUsers();
      
      // Initialize Lucide icons
      lucide.createIcons();
    </script>
  </body>
</html>
`;

const casesPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Casos - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">
            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"/>
              <path stroke-linecap="round" stroke-linejoin="round" d="M8 21v-4a2 2 0 012-2h4a2 2 0 012 2v4"/>
            </svg>
            Sistema Jurídico
          </a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7"/>
              </svg>
              Dashboard
            </a>
            <a href="/users" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
              </svg>
              Usuários
            </a>
            <a href="/cases" class="tab-link active">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              Casos
            </a>
            <a href="/documents" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              Documentos
            </a>
            <a href="/hearings" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 0V6a2 2 0 012-2h4a2 2 0 012 2v1m-6 0h8m-9 0a1 1 0 00-1 1v10a1 1 0 001 1h10a1 1 0 001-1V8a1 1 0 00-1-1H7z"/>
              </svg>
              Audiências
            </a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Gerenciamento de Casos</h1>
          <p class="page-subtitle">Acompanhe processos judiciais e gerencie documentação</p>
          <button class="btn btn-primary" onclick="openCaseModal()">+ Novo Caso</button>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Lista de Casos Jurídicos</div>
            <div class="search-container">
              <input type="text" id="caseSearch" placeholder="Buscar casos..." style="padding: 0.5rem; border: 1px solid #e1e5e9; border-radius: 0.375rem; font-size: 0.875rem;">
            </div>
          </div>
          
          <div id="message" style="display:none;padding:1rem;margin:1rem;border-radius:0.5rem;"></div>
          
          <div class="table-container">
            <table class="table" id="cases-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Título</th>
                  <th>Categoria</th>
                  <th>Status</th>
                  <th>Prioridade</th>
                  <th>Data Criação</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="cases-tbody">
                <tr>
                  <td>001/2024</td>
                  <td>Ação Trabalhista - Silva vs Empresa XYZ</td>
                  <td>Trabalhista</td>
                  <td><span class="status-badge active">Em andamento</span></td>
                  <td><span class="priority high">Alta</span></td>
                  <td>15/01/2024</td>
                  <td>
                    <button class="btn-sm btn-secondary">Ver</button>
                    <button class="btn-sm btn-primary">Editar</button>
                  </td>
                </tr>
                <tr>
                  <td>002/2024</td>
                  <td>Ação Cível - Cobrança de Dívida</td>
                  <td>Cível</td>
                  <td><span class="status-badge pending">Aguardando</span></td>
                  <td><span class="priority medium">Média</span></td>
                  <td>10/01/2024</td>
                  <td>
                    <button class="btn-sm btn-outline">Ver</button>
                    <button class="btn-sm btn-action">Editar</button>
                  </td>
                </tr>
                <tr>
                  <td>003/2024</td>
                  <td>Divorcio Consensual - Casal Costa</td>
                  <td>Família</td>
                  <td><span class="status-badge inactive">Finalizado</span></td>
                  <td><span class="priority low">Baixa</span></td>
                  <td>05/01/2024</td>
                  <td>
                    <button class="btn-sm btn-outline">Ver</button>
                    <button class="btn-sm btn-action">Editar</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📊</div>
              <div class="card-title">Estatísticas de Casos</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">24</div>
                <div style="font-size: 0.875rem; color: #64748b;">Casos Ativos</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">8</div>
                <div style="font-size: 0.875rem; color: #64748b;">Finalizados</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">5</div>
                <div style="font-size: 0.875rem; color: #64748b;">Urgentes</div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">⚖️</div>
              <div class="card-title">Categorias de Casos</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Civil</span>
                <span style="font-weight: 600;">12 casos</span>
              </div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Trabalhista</span>
                <span style="font-weight: 600;">8 casos</span>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span>Criminal</span>
                <span style="font-weight: 600;">4 casos</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Case Modal -->
    <div id="caseModal" class="modal">
      <div class="modal-content">
        <span class="modal-close" onclick="closeCaseModal()">&times;</span>
        <h3 id="modal-title">Adicionar Caso</h3>
        <form id="caseForm">
          <div class="form-group">
            <label class="form-label">Título:</label>
            <input type="text" class="form-input" id="caseTitle" required />
          </div>
          <div class="form-group">
            <label class="form-label">Descrição:</label>
            <textarea class="form-input" id="caseDescription" rows="3"></textarea>
          </div>
          <div class="form-group">
            <label class="form-label">Categoria:</label>
            <select class="form-input" id="caseCategory">
              <option value="civil">Civil</option>
              <option value="criminal">Criminal</option>
              <option value="trabalhista">Trabalhista</option>
              <option value="tributario">Tributário</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Prioridade:</label>
            <select class="form-input" id="casePriority">
              <option value="low">Baixa</option>
              <option value="medium">Média</option>
              <option value="high">Alta</option>
            </select>
          </div>
          <button type="submit" class="btn">Salvar</button>
          <button type="button" class="btn btn-danger" onclick="closeCaseModal()">Cancelar</button>
        </form>
      </div>
    </div>

    <script>
      let cases = [];
      let editingCaseId = null;

      async function loadCases() {
        try {
          const response = await fetch('http://localhost:3333/litigation/cases');
          cases = await response.json();
          renderCases();
        } catch (error) {
          showMessage('Erro ao carregar casos', 'error');
        }
      }

      function renderCases() {
        const tbody = document.getElementById('cases-tbody');
        tbody.innerHTML = cases.map(caseItem => 
          \`<tr>
            <td>\${caseItem.id}</td>
            <td>\${caseItem.title}</td>
            <td>\${caseItem.category}</td>
            <td>\${caseItem.status}</td>
            <td>\${caseItem.priority}</td>
            <td>\${new Date(caseItem.createdAt).toLocaleDateString()}</td>
            <td>
              <button class="btn" onclick="viewCase(\${caseItem.id})">Ver</button>
              <button class="btn" onclick="editCase(\${caseItem.id})">Editar</button>
              <button class="btn btn-danger" onclick="deleteCase(\${caseItem.id})">Excluir</button>
            </td>
          </tr>\`
        ).join('');
      }

      function openCaseModal(caseItem = null) {
        const modal = document.getElementById('caseModal');
        const title = document.getElementById('modal-title');
        
        if (caseItem) {
          title.textContent = 'Editar Caso';
          document.getElementById('caseTitle').value = caseItem.title;
          document.getElementById('caseDescription').value = caseItem.description;
          document.getElementById('caseCategory').value = caseItem.category;
          document.getElementById('casePriority').value = caseItem.priority;
          editingCaseId = caseItem.id;
        } else {
          title.textContent = 'Adicionar Caso';
          document.getElementById('caseForm').reset();
          editingCaseId = null;
        }
        
        modal.classList.add('show');
      }

      function closeCaseModal() {
        document.getElementById('caseModal').classList.remove('show');
      }

      function viewCase(id) {
        window.location.href = \`/case-details?id=\${id}\`;
      }

      function editCase(id) {
        const caseItem = cases.find(c => c.id === id);
        if (caseItem) openCaseModal(caseItem);
      }

      async function deleteCase(id) {
        if (!confirm('Tem certeza que deseja excluir este caso?')) return;
        
        try {
          await fetch('http://localhost:3333/litigation/cases/' + id, { method: 'DELETE' });
          showMessage('Caso excluído com sucesso', 'success');
          loadCases();
        } catch (error) {
          showMessage('Erro ao excluir caso', 'error');
        }
      }

      function showMessage(text, type) {
        const message = document.getElementById('message');
        message.textContent = text;
        message.className = type;
        message.style.display = 'block';
        setTimeout(() => message.style.display = 'none', 3000);
      }

      function logout() {
        window.location.href = '/login';
      }

      document.getElementById('caseForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const caseData = {
          title: document.getElementById('caseTitle').value,
          description: document.getElementById('caseDescription').value,
          category: document.getElementById('caseCategory').value,
          priority: document.getElementById('casePriority').value,
          status: 'active'
        };

        try {
          const url = editingCaseId ? 
            'http://localhost:3333/litigation/cases/' + editingCaseId : 
            'http://localhost:3333/litigation/cases';
          const method = editingCaseId ? 'PUT' : 'POST';

          await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(caseData)
          });

          showMessage(\`Caso \${editingCaseId ? 'atualizado' : 'criado'} com sucesso\`, 'success');
          closeCaseModal();
          loadCases();
        } catch (error) {
          showMessage('Erro ao salvar caso', 'error');
        }
      });

      // Load cases on page load
      loadCases();
      
      // Initialize Lucide icons
      lucide.createIcons();
    </script>
  </body>
</html>
`;

const documentsPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Documentos - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">
            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"/>
              <path stroke-linecap="round" stroke-linejoin="round" d="M8 21v-4a2 2 0 012-2h4a2 2 0 012 2v4"/>
            </svg>
            Sistema Jurídico
          </a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7"/>
              </svg>
              Dashboard
            </a>
            <a href="/users" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
              </svg>
              Usuários
            </a>
            <a href="/cases" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              Casos
            </a>
            <a href="/documents" class="tab-link active">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              Documentos
            </a>
            <a href="/hearings" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 0V6a2 2 0 012-2h4a2 2 0 012 2v1m-6 0h8m-9 0a1 1 0 00-1 1v10a1 1 0 001 1h10a1 1 0 001-1V8a1 1 0 00-1-1H7z"/>
              </svg>
              Audiências
            </a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Gerenciamento de Documentos</h1>
          <p class="page-subtitle">Organize e gerencie documentos legais e contratos</p>
          <button class="btn btn-primary" onclick="openDocModal()">+ Novo Documento</button>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Biblioteca de Documentos</div>
            <div class="search-container">
              <input type="text" id="docSearch" placeholder="Buscar documentos..." style="padding: 0.5rem; border: 1px solid #e1e5e9; border-radius: 0.375rem; font-size: 0.875rem;">
            </div>
          </div>
          
          <div id="message" style="display:none;padding:1rem;margin:1rem;border-radius:0.5rem;"></div>
          
          <div class="table-container">
            <table class="table" id="documents-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nome</th>
                  <th>Tipo</th>
                  <th>Caso ID</th>
                  <th>Data Upload</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="documents-tbody">
                <tr>
                  <td>1</td>
                  <td>Petição Inicial - Caso 001/2024</td>
                  <td>Petição</td>
                  <td>2.5 MB</td>
                  <td>15/01/2024</td>
                  <td>
                    <button class="btn-sm btn-secondary">Download</button>
                    <button class="btn-sm btn-primary">Ver</button>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Contrato de Trabalho - Silva</td>
                  <td>Contrato</td>
                  <td>1.2 MB</td>
                  <td>12/01/2024</td>
                  <td>
                    <button class="btn-sm btn-secondary">Download</button>
                    <button class="btn-sm btn-primary">Ver</button>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Certidão de Nascimento - Costa</td>
                  <td>Certidão</td>
                  <td>0.8 MB</td>
                  <td>08/01/2024</td>
                  <td>
                    <button class="btn-sm btn-secondary">Download</button>
                    <button class="btn-sm btn-primary">Ver</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📊</div>
              <div class="card-title">Estatísticas de Documentos</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">156</div>
                <div style="font-size: 0.875rem; color: #64748b;">Total Documentos</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">42</div>
                <div style="font-size: 0.875rem; color: #64748b;">Este Mês</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">8</div>
                <div style="font-size: 0.875rem; color: #64748b;">Pendentes</div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📄</div>
              <div class="card-title">Tipos de Documentos</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Petições</span>
                <span style="font-weight: 600;">45 docs</span>
              </div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Contratos</span>
                <span style="font-weight: 600;">38 docs</span>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span>Evidências</span>
                <span style="font-weight: 600;">73 docs</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Document Modal -->
    <div id="docModal" class="modal">
      <div class="modal-content">
        <span class="modal-close" onclick="closeDocModal()">&times;</span>
        <h3>Adicionar Documento</h3>
        <form id="docForm">
          <div class="form-group">
            <label class="form-label">Nome do Documento:</label>
            <input type="text" class="form-input" id="docName" required />
          </div>
          <div class="form-group">
            <label class="form-label">Tipo:</label>
            <select class="form-input" id="docType">
              <option value="petition">Petição</option>
              <option value="evidence">Evidência</option>
              <option value="contract">Contrato</option>
              <option value="ruling">Decisão</option>
              <option value="other">Outro</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">ID do Caso:</label>
            <input type="number" class="form-input" id="docCaseId" required />
          </div>
          <div class="form-group">
            <label class="form-label">Arquivo (Simulado):</label>
            <input type="file" class="form-input" id="docFile" />
          </div>
          <button type="submit" class="btn">Salvar</button>
          <button type="button" class="btn btn-danger" onclick="closeDocModal()">Cancelar</button>
        </form>
      </div>
    </div>

    <script>
      let documents = [];

      async function loadDocuments() {
        try {
          const response = await fetch('http://localhost:3333/documents');
          documents = await response.json();
          renderDocuments();
        } catch (error) {
          showMessage('Erro ao carregar documentos', 'error');
        }
      }

      function renderDocuments() {
        const tbody = document.getElementById('documents-tbody');
        tbody.innerHTML = documents.map(doc => 
          \`<tr>
            <td>\${doc.id}</td>
            <td>\${doc.name}</td>
            <td>\${doc.type}</td>
            <td>\${doc.caseId}</td>
            <td>\${new Date(doc.uploadedAt).toLocaleDateString()}</td>
            <td>
              <button class="btn" onclick="downloadDoc(\${doc.id})">Download</button>
              <button class="btn btn-danger" onclick="deleteDoc(\${doc.id})">Excluir</button>
            </td>
          </tr>\`
        ).join('');
      }

      function openDocModal() {
        document.getElementById('docModal').classList.add('show');
      }

      function closeDocModal() {
        document.getElementById('docModal').classList.remove('show');
      }

      function downloadDoc(id) {
        showMessage('Download iniciado (simulado)', 'success');
      }

      async function deleteDoc(id) {
        if (!confirm('Tem certeza que deseja excluir este documento?')) return;
        
        try {
          const response = await fetch('http://localhost:3333/documents/' + id, {
            method: 'DELETE'
          });

          if (response.ok) {
            showMessage('Documento excluído com sucesso', 'success');
            loadDocuments(); // Reload from API
          } else {
            throw new Error('Failed to delete document');
          }
        } catch (error) {
          showMessage('Erro ao excluir documento', 'error');
        }
      }

      function showMessage(text, type) {
        const message = document.getElementById('message');
        message.textContent = text;
        message.className = type;
        message.style.display = 'block';
        setTimeout(() => message.style.display = 'none', 3000);
      }

      function logout() {
        window.location.href = '/login';
      }

      document.getElementById('docForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const docData = {
          name: document.getElementById('docName').value,
          type: document.getElementById('docType').value,
          caseId: parseInt(document.getElementById('docCaseId').value)
        };

        try {
          const response = await fetch('http://localhost:3333/documents', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(docData)
          });

          if (response.ok) {
            showMessage('Documento adicionado com sucesso', 'success');
            closeDocModal();
            document.getElementById('docForm').reset();
            loadDocuments(); // Reload from API
          } else {
            throw new Error('Failed to create document');
          }
        } catch (error) {
          showMessage('Erro ao salvar documento', 'error');
        }
      });

      loadDocuments();
      
      // Initialize Lucide icons
      lucide.createIcons();
    </script>
  </body>
</html>
`;

const hearingsPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Audiências - Sistema Jurídico</title>
    <mcript src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
    <seta name="viewport" content="width=device-width, initial-scale=1" />
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">
            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2H5a2 2 0 00-2-2z"/>
              <path stroke-linecap="round" stroke-linejoin="round" d="M8 21v-4a2 2 0 012-2h4a2 2 0 012 2v4"/>
            </svg>
            Sistema Jurídico
          </a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h7"/>
              </svg>
              Dashboard
            </a>
            <a href="/users" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z"/>
              </svg>
              Usuários
            </a>
            <a href="/cases" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              Casos
            </a>
            <a href="/documents" class="tab-link">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
              </svg>
              Documentos
            </a>
            <a href="/hearings" class="tab-link active">
              <svg class="tab-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 0V6a2 2 0 012-2h4a2 2 0 012 2v1m-6 0h8m-9 0a1 1 0 00-1 1v10a1 1 0 001 1h10a1 1 0 001-1V8a1 1 0 00-1-1H7z"/>
              </svg>
              Audiências
            </a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Gerenciamento de Audiências</h1>
          <p class="page-subtitle">Agende audiências e gerencie calendário judicial</p>
          <button class="btn btn-primary" onclick="openHearingModal()">+ Nova Audiência</button>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Calendário de Audiências</div>
            <div class="search-container">
              <input type="text" id="hearingSearch" placeholder="Buscar audiências..." style="padding: 0.5rem; border: 1px solid #e1e5e9; border-radius: 0.375rem; font-size: 0.875rem;">
            </div>
          </div>
          
          <div id="message" style="display:none;padding:1rem;margin:1rem;border-radius:0.5rem;"></div>
          
          <div class="table-container">
            <table class="table" id="hearings-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Tipo</th>
                  <th>Data/Hora</th>
                  <th>Local</th>
                  <th>Caso ID</th>
                  <th>Status</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="hearings-tbody">
                <tr>
                  <td>1</td>
                  <td>Audiência Inicial - Caso 001/2024</td>
                  <td>25/01/2024</td>
                  <td>14:30</td>
                  <td>Sala 101 - Fórum Central</td>
                  <td><span class="status-badge active">Agendada</span></td>
                  <td>
                    <button class="btn-sm btn-secondary">Detalhes</button>
                    <button class="btn-sm btn-primary">Editar</button>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Audiência de Conciliação</td>
                  <td>30/01/2024</td>
                  <td>09:00</td>
                  <td>Sala Virtual - Teams</td>
                  <td><span class="status-badge pending">Pendente</span></td>
                  <td>
                    <button class="btn-sm btn-secondary">Detalhes</button>
                    <button class="btn-sm btn-primary">Editar</button>
                  </td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Audiência de Instrução</td>
                  <td>15/01/2024</td>
                  <td>15:00</td>
                  <td>Sala 205 - Fórum Trabalhista</td>
                  <td><span class="status-badge inactive">Realizada</span></td>
                  <td>
                    <button class="btn-sm btn-secondary">Detalhes</button>
                    <button class="btn-sm btn-primary">Editar</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📅</div>
              <div class="card-title">Próximas Audiências</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 0; border-bottom: 1px solid #f1f5f9;">
                <div>
                  <div style="font-weight: 600; color: #1f2937;">Audiência Inicial</div>
                  <div style="color: #64748b;">Caso Silva vs. Santos</div>
                </div>
                <div style="text-align: right;">
                  <div style="font-weight: 600; color: #667eea;">15/01/2026</div>
                  <div style="color: #64748b;">14:30</div>
                </div>
              </div>
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 0; border-bottom: 1px solid #f1f5f9;">
                <div>
                  <div style="font-weight: 600; color: #1f2937;">Conciliação</div>
                  <div style="color: #64748b;">Caso Oliveira vs. Empresa</div>
                </div>
                <div style="text-align: right;">
                  <div style="font-weight: 600; color: #667eea;">18/01/2026</div>
                  <div style="color: #64748b;">09:00</div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📊</div>
              <div class="card-title">Estatísticas de Audiências</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">12</div>
                <div style="font-size: 0.875rem; color: #64748b;">Este Mês</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">8</div>
                <div style="font-size: 0.875rem; color: #64748b;">Realizadas</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">4</div>
                <div style="font-size: 0.875rem; color: #64748b;">Agendadas</div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Hearing Modal -->
    <div id="hearingModal" class="modal">
      <div class="modal-content">
        <span class="modal-close" onclick="closeHearingModal()">&times;</span>
        <h3>Agendar Audiência</h3>
        <form id="hearingForm">
          <div class="form-group">
            <label class="form-label">Tipo:</label>
            <select class="form-input" id="hearingType">
              <option value="initial">Inicial</option>
              <option value="testimony">Testemunhal</option>
              <option value="conciliation">Conciliação</option>
              <option value="judgment">Julgamento</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Data:</label>
            <input type="date" class="form-input" id="hearingDate" required />
          </div>
          <div class="form-group">
            <label class="form-label">Horário:</label>
            <input type="time" class="form-input" id="hearingTime" required />
          </div>
          <div class="form-group">
            <label class="form-label">Local:</label>
            <input type="text" class="form-input" id="hearingLocation" required />
          </div>
          <div class="form-group">
            <label class="form-label">ID do Caso:</label>
            <input type="number" class="form-input" id="hearingCaseId" required />
          </div>
          <button type="submit" class="btn">Agendar</button>
          <button type="button" class="btn btn-danger" onclick="closeHearingModal()">Cancelar</button>
        </form>
      </div>
    </div>

    <script>
      let hearings = [];

      async function loadHearings() {
        try {
          const response = await fetch('http://localhost:3333/hearings');
          hearings = await response.json();
          renderHearings();
        } catch (error) {
          showMessage('Erro ao carregar audiências', 'error');
        }
      }

      function renderHearings() {
        const tbody = document.getElementById('hearings-tbody');
        tbody.innerHTML = hearings.map(hearing => 
          \`<tr>
            <td>\${hearing.id}</td>
            <td>\${hearing.type}</td>
            <td>\${new Date(hearing.dateTime).toLocaleString()}</td>
            <td>\${hearing.location}</td>
            <td>\${hearing.caseId}</td>
            <td>\${hearing.status}</td>
            <td>
              <button class="btn" onclick="editHearing(\${hearing.id})">Editar</button>
              <button class="btn btn-danger" onclick="cancelHearing(\${hearing.id})">Cancelar</button>
            </td>
          </tr>\`
        ).join('');
      }

      function openHearingModal() {
        document.getElementById('hearingModal').classList.add('show');
      }

      function closeHearingModal() {
        document.getElementById('hearingModal').classList.remove('show');
      }

      function editHearing(id) {
        showMessage('Função de edição em desenvolvimento', 'success');
      }

      function cancelHearing(id) {
        if (!confirm('Tem certeza que deseja cancelar esta audiência?')) return;
        const hearing = hearings.find(h => h.id === id);
        if (hearing) {
          hearing.status = 'cancelled';
          renderHearings();
          showMessage('Audiência cancelada com sucesso', 'success');
        }
      }

      function showMessage(text, type) {
        const message = document.getElementById('message');
        message.textContent = text;
        message.className = type;
        message.style.display = 'block';
        setTimeout(() => message.style.display = 'none', 3000);
      }

      function logout() {
        window.location.href = '/login';
      }

      document.getElementById('hearingForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const hearingData = {
          type: document.getElementById('hearingType').value,
          date: document.getElementById('hearingDate').value,
          time: document.getElementById('hearingTime').value,
          location: document.getElementById('hearingLocation').value,
          caseId: parseInt(document.getElementById('hearingCaseId').value)
        };

        try {
          const response = await fetch('http://localhost:3333/hearings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(hearingData)
          });

          if (response.ok) {
            showMessage('Audiência agendada com sucesso', 'success');
            closeHearingModal();
            document.getElementById('hearingForm').reset();
            loadHearings(); // Reload from API
          } else {
            throw new Error('Failed to create hearing');
          }
        } catch (error) {
          showMessage('Erro ao agendar audiência', 'error');
        }
      
      // Initialize Lucide icons
      lucide.createIcons();
      });

      loadHearings();
    </script>
  </body>
</html>
`;

const server = http.createServer((req, res) => {
  const url = req.url;
  
  // Route handling
  if (req.method === 'GET' && url === '/login') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(loginPage);
    return;
  }
  
  if (req.method === 'GET' && url === '/dashboard') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(dashboardPage);
    return;
  }

  if (req.method === 'GET' && url === '/users') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(usersPage);
    return;
  }

  if (req.method === 'GET' && url === '/cases') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(casesPage);
    return;
  }

  if (req.method === 'GET' && url === '/documents') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(documentsPage);
    return;
  }

  if (req.method === 'GET' && url === '/hearings') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(hearingsPage);
    return;
  }
  
  // Default redirect to login for root
  if (req.method === 'GET' && (url === '/' || url === '')) {
    res.writeHead(302, { 'Location': '/login' });
    res.end();
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end('<h1>404 - Page Not Found</h1><p><a href="/login">Go to Login</a></p>');
});

const port = 3000;
server.listen(port, () => console.log(`Mock UI listening on http://localhost:${port}`));

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));