// test-mocks/stop-mocks.js
const fs = require('fs');

function killPidFile(path) {
  if (fs.existsSync(path)) {
    try {
      const pid = Number(fs.readFileSync(path, 'utf8').trim());
      process.kill(pid);
      console.log('Killed PID', pid);
    } catch (err) {
      console.warn('Failed to kill PID from', path, err.message);
    }
    try { fs.unlinkSync(path); } catch (e) {}
  }
}

killPidFile('.mock_api_pid');
killPidFile('.mock_ui_pid');
