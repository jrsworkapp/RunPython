import { test, expect, request } from '@playwright/test';

test.describe('Users API', () => {
  test('GET /users returns a list', async () => {
    const apiContext = await request.newContext({ baseURL: 'http://localhost:3333' });
    const response = await apiContext.get('/users');
    expect(response.status()).toBe(200);
    const body = await response.json();
    expect(Array.isArray(body)).toBeTruthy();
    expect(body.length).toBeGreaterThan(0);
    await apiContext.dispose();
  });
});
