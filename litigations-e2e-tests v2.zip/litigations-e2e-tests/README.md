# E2E Tests (Litigations)

Resumo rápido
- Testes BDD com Cucumber: features + steps em `tests/features` e `tests/steps`.
- Testes Playwright: specs em `tests/**/*.spec.ts`.
- Page objects e helpers: código fonte reutilizável em `src/`.
- Mocks leves para execução local em `test-mocks/`.

Estrutura recomendada
```
.
├─ package.json
├─ playwright.config.ts
├─ README.md
├─ test-mocks/               # servidores mock para API e UI (local)
├─ tests/
│  ├─ features/              # Cucumber .feature files (BDD)
│  │  ├─ api/
│  │  └─ ui/
│  ├─ steps/                 # Cucumber step definitions (TypeScript)
│  ├─ api/                   # Playwright API specs (optional/migration)
│  └─ ui/                    # Playwright UI specs (optional/migration)
└─ src/
   ├─ api/
   │  └─ helpers/            # apiClient, helpers reutilizáveis
   └─ ui/
      └─ pages/              # page objects (LoginPage.ts etc.)
```

Como usar (comandos)

Instalar dependências:
```bash
npm install
```

Iniciar mocks manualmente (em background/terminal separado):
```bash
npm run mock:api   # inicia mock da API em http://localhost:3333
npm run mock:ui    # inicia mock UI em http://localhost:3000
```

Scripts úteis (npm)
- `npm run start:mocks` — inicia ambos os mocks (gera `.mock_api_pid` e `.mock_ui_pid`).
- `npm run stop:mocks` — para os mocks a partir dos arquivos PID.
- `npm run test:cucumber` — roda todas as features Cucumber em `tests/features`.
- `npm run test:playwright` — roda os testes Playwright (specs `.spec.ts`).
- `npm run test:all` — inicia mocks, roda Cucumber + Playwright e para os mocks automaticamente.

Executando apenas Cucumber (BDD)
```bash
# executar todas as features
npm run test:cucumber

# executar apenas features de API
npm run test:api:cucumber

# executar apenas features de UI
npm run test:ui:cucumber
```

Executando Playwright (exemplos)
```bash
npm run test:playwright
```

Mock API
- URL base: `http://localhost:3333`
- Endpoints principais expostos pelo mock:
  - `GET /users` — retorna lista de usuários mock
  - `POST /auth/login` — autentica `admin`/`admin` e retorna `{ token: "<JWT>" }`
  - `GET /openapi.json` — especificação OpenAPI (Swagger)
  - `GET /docs` — Swagger UI (via CDN)

Notas sobre organização e migração
- Mantivemos a convenção: page objects e helpers em `src/` (reutilizáveis). Tests e BDD em `tests/`.
- Para migrar um cenário Cucumber para Playwright Test:
  1. Crie um arquivo `tests/ui/xxx.spec.ts` ou `tests/api/xxx.spec.ts`.
 2. Reuse `src/ui/pages/*` e `src/api/helpers/*` para evitar duplicação.

Boas práticas
- Prefira manter os *page objects* e *helpers* (src/) separados dos testes.
- Mantenha features BDD em `tests/features` para visibilidade do time.
- Use `test:all` em CI (ajuste para iniciar serviços reais ou mocks conforme ambiente).

- Variáveis de ambiente importantes
- `HEADLESS`: `true|false` — controla se o browser roda em modo headless (padrão: `true`).
- `CI`: `true|false` — quando `true` força `HEADLESS=true` (útil em pipelines).
- `API_BASE_URL`: URL base para chamadas de API nos testes (padrão: `http://localhost:3333`).
- `BASE_URL`: URL base para testes UI/pages (padrão: `http://localhost:3000`).

Local de Page Objects
- Page objects agora estão em `tests/support/pages` (próximo aos testes). Se preferir compartilhá-los com outros pacotes, mantenha em `src/ui/pages`.

Reuso de browser por worker/processo
- Para reduzir tempo de inicialização, os hooks do Cucumber usam um browser compartilhado por processo (lançado em `BeforeAll` e fechado em `AfterAll`). Cada cenário cria um `BrowserContext` e `Page` a partir desse browser compartilhado — isso mantém isolamento entre cenários enquanto diminui overhead.

Se preferir comportamento antigo (browser por cenário), posso reverter para essa abordagem.

Git / Backup
- Recomendo inicializar um repositório git e commitar a árvore atual antes de grandes mudanças.
  Se quiser, posso inicializar git e criar um commit snapshot para você.

Contato
- Se quiser que eu faça a migração completa das features para Playwright, ou inicialize git e crie commits, diga qual opção prefere.

----
Arquivo gerado automaticamente para documentar a convenção e os comandos do projeto.
