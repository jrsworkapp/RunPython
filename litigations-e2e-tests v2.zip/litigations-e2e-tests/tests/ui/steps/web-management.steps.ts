import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { LoginPage } from '../support/LoginPage';
import { UsersPage } from '../support/UsersPage';

Given('que estou logado no sistema', async function () {
  const loginPage = new LoginPage(this.page);
  await loginPage.goto();
  await loginPage.fillEmail('user@test.com');
  await loginPage.fillPassword('123456');
  await loginPage.submit();
  await this.page.waitForURL('**/dashboard');
});

When('eu acesso a página de usuários', async function () {
  this.usersPage = new UsersPage(this.page);
  await this.usersPage.goto();
});

Then('devo ver a lista de usuários cadastrados', async function () {
  await expect(this.usersPage.usersTable).toBeVisible();
});

Then('devo ver o botão {string}', async function (buttonText: string) {
  if (buttonText === 'Adicionar Usuário') {
    await expect(this.usersPage.addUserButton).toBeVisible();
  } else {
    const button = this.page.getByRole('button', { name: buttonText });
    await expect(button).toBeVisible();
  }
});

When('eu clico no botão {string}', async function (buttonText: string) {
  if (buttonText === 'Adicionar Usuário') {
    await this.usersPage.clickAddUser();
  } else {
    const button = this.page.getByRole('button', { name: buttonText });
    await button.click();
  }
});

When('eu preencho o formulário de usuário com nome {string}, email {string} e papel {string}', async function (nome: string, email: string, papel: string) {
  await this.usersPage.fillUserForm(nome, email, papel);
});

When('eu clico em {string}', async function (buttonText: string) {
  const button = this.page.getByText(buttonText).first();
  await button.click();
});

Then('devo ver a mensagem de sucesso {string}', async function (expectedMessage: string) {
  await this.page.waitForTimeout(500); // Wait for message to appear
  
  // Check for message in generic message div (works for all pages)
  const messageElement = this.page.locator('#message');
  const message = await messageElement.textContent();
  
  expect(message).toContain(expectedMessage.replace('Usuário criado com sucesso', 'criado')
                                       .replace('Caso criado com sucesso', 'criado')
                                       .replace('Documento criado com sucesso', 'criado')
                                       .replace('Audiência criada com sucesso', 'criado')
                                       .replace('Download iniciado com sucesso', 'Download'));
});

Then('o usuário {string} deve aparecer na lista', async function (userName: string) {
  await this.page.waitForTimeout(1000); // Wait for table to refresh
  const isVisible = await this.usersPage.isUserInTable(userName);
  expect(isVisible).toBeTruthy();
});

Given('que existe um usuário {string} na lista', async function (userName: string) {
  // Create the user through the API to ensure it exists
  const userData = {
    name: userName,
    email: `${userName.toLowerCase().replace(' ', '.')}@example.com`,
    role: 'lawyer'
  };
  
  try {
    const response = await fetch('http://localhost:3333/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    if (!response.ok) {
      throw new Error(`Failed to create user: ${response.statusText}`);
    }
  } catch (error) {
    console.log('Error creating user:', error);
  }
  
  this.testUserName = userName;
});

When('eu clico em {string} para o usuário {string}', async function (action: string, userName: string) {
  if (action === 'Editar') {
    await this.usersPage.editUser(userName);
  } else if (action === 'Excluir') {
    await this.usersPage.confirmAction();
    await this.usersPage.deleteUser(userName);
  }
});

When('eu altero o nome para {string}', async function (newName: string) {
  await this.usersPage.userNameInput.clear();
  await this.usersPage.userNameInput.fill(newName);
});

Then('o usuário deve aparecer como {string}', async function (newName: string) {
  await this.page.waitForTimeout(1000); // Wait for table to refresh
  const isVisible = await this.usersPage.isUserInTable(newName);
  expect(isVisible).toBeTruthy();
});

When('eu confirmo a exclusão', async function () {
  // Dialog handler is set in the page object
  await this.page.waitForTimeout(500);
});

Then('o usuário {string} não deve mais aparecer na lista', async function (userName: string) {
  await this.page.waitForTimeout(1000); // Wait for table to refresh
  const isVisible = await this.usersPage.isUserInTable(userName);
  expect(isVisible).toBeFalsy();
});