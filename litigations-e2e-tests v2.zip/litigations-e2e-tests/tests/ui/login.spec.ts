import { test, expect } from '@playwright/test';
import { LoginPage } from './support/LoginPage';

test('successful login shows welcome message', async ({ page }) => {
  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.fillEmail('user@test.com');
  await loginPage.fillPassword('123456');
  await loginPage.submit();
  const visible = await loginPage.hasWelcomeMessage();
  expect(visible).toBeTruthy();
  const text = await loginPage.getWelcomeText();
  if (text) expect(text).toContain('Bem-vindo');
});
