// test-mocks/mock-ui.js
const http = require('http');

// Simulate session state
let isAuthenticated = false;
let currentUser = null;

const commonStyles = `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  
  body { 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
    background-color: #f8fafc;
    color: #334155;
    line-height: 1.6;
  }
  
  .app-container { 
    min-height: 100vh; 
    display: flex; 
    flex-direction: column; 
  }
  
  /* Navigation Bar */
  .navbar { 
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    position: relative;
    z-index: 100;
  }
  
  .navbar-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 64px;
  }
  
  .navbar-brand {
    color: white;
    font-size: 1.5rem;
    font-weight: 600;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
  
  .navbar-brand::before {
    content: '⚖️';
    font-size: 1.8rem;
  }
  
  /* Tab Navigation */
  .tab-navigation {
    display: flex;
    gap: 0.5rem;
  }
  
  .tab-link {
    color: rgba(255, 255, 255, 0.8);
    text-decoration: none;
    padding: 0.5rem 1rem;
    border-radius: 6px;
    transition: all 0.2s ease;
    font-weight: 500;
    position: relative;
    font-size: 0.9rem;
  }
  
  .tab-link:hover {
    color: white;
    background-color: rgba(255, 255, 255, 0.1);
  }
  
  .tab-link.active {
    color: white;
    background-color: rgba(255, 255, 255, 0.2);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  .tab-link.active::after {
    content: '';
    position: absolute;
    bottom: -4px;
    left: 50%;
    transform: translateX(-50%);
    width: 20px;
    height: 2px;
    background: white;
    border-radius: 1px;
  }
  
  .user-menu {
    display: flex;
    align-items: center;
    gap: 1rem;
  }
  
  .user-info {
    color: rgba(255, 255, 255, 0.9);
    font-size: 0.875rem;
  }
  
  .logout-btn {
    background: rgba(255, 255, 255, 0.2);
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.2s ease;
    font-size: 0.875rem;
  }
  
  .logout-btn:hover {
    background: rgba(255, 255, 255, 0.3);
  }
  
  /* Main Content */
  .main-content {
    flex: 1;
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem 1rem;
    width: 100%;
  }
  
  .page-header {
    margin-bottom: 2rem;
  }
  
  .page-title {
    font-size: 1.875rem;
    font-weight: 700;
    color: #1e293b;
    margin-bottom: 0.5rem;
  }
  
  .page-subtitle {
    color: #64748b;
    font-size: 1rem;
  }
  
  /* Cards */
  .cards-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.5rem;
    margin-top: 2rem;
  }
  
  .card {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    border: 1px solid #e2e8f0;
    transition: all 0.2s ease;
  }
  
  .card:hover {
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
    transform: translateY(-1px);
  }
  
  .card-header {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 1rem;
  }
  
  .card-icon {
    font-size: 1.5rem;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 8px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
  }
  
  .card-title {
    font-size: 1.25rem;
    font-weight: 600;
    color: #1e293b;
  }
  
  .card-description {
    color: #64748b;
    margin-bottom: 1.5rem;
    line-height: 1.5;
  }
  
  /* Buttons */
  .btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.625rem 1rem;
    border: none;
    border-radius: 6px;
    font-weight: 500;
    font-size: 0.875rem;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
    line-height: 1;
  }
  
  .btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
  }
  
  .btn-primary:hover {
    opacity: 0.9;
    transform: translateY(-1px);
  }
  
  .btn-secondary {
    background: #f1f5f9;
    color: #475569;
    border: 1px solid #e2e8f0;
  }
  
  .btn-secondary:hover {
    background: #e2e8f0;
  }
  
  .btn-danger {
    background: #ef4444;
    color: white;
  }
  
  .btn-danger:hover {
    background: #dc2626;
  }
  
  /* Table */
  .table-container {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    border: 1px solid #e2e8f0;
  }
  
  .table {
    width: 100%;
    border-collapse: collapse;
  }
  
  .table th {
    background: #f8fafc;
    padding: 0.875rem 1rem;
    text-align: left;
    font-weight: 600;
    color: #374151;
    border-bottom: 1px solid #e2e8f0;
    font-size: 0.875rem;
  }
  
  .table td {
    padding: 0.875rem 1rem;
    border-bottom: 1px solid #f1f5f9;
    font-size: 0.875rem;
  }
  
  .table tbody tr:hover {
    background: #f8fafc;
  }
  
  /* Forms */
  .form-group {
    margin-bottom: 1rem;
  }
  
  .form-label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: #374151;
    font-size: 0.875rem;
  }
  
  .form-input, .form-select {
    width: 100%;
    padding: 0.625rem 0.875rem;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 0.875rem;
    transition: border-color 0.2s ease;
    background: white;
  }
  
  .form-input:focus, .form-select:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  /* Modal */
  .modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(2px);
  }
  
  .modal.show {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
  }
  
  .modal-content {
    background: white;
    border-radius: 12px;
    width: 100%;
    max-width: 500px;
    max-height: 80vh;
    overflow-y: auto;
    position: relative;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
  }
  
  .modal-header {
    padding: 1.5rem 1.5rem 0 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .modal-title {
    font-size: 1.25rem;
    font-weight: 600;
    color: #1e293b;
  }
  
  .modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #64748b;
    padding: 0.25rem;
    border-radius: 4px;
  }
  
  .modal-close:hover {
    background: #f1f5f9;
  }
  
  .modal-body {
    padding: 1.5rem;
  }
  
  /* Messages */
  .message {
    padding: 0.875rem 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
    font-size: 0.875rem;
    font-weight: 500;
  }
  
  .message.success {
    background: #dcfce7;
    color: #166534;
    border: 1px solid #bbf7d0;
  }
  
  .message.error {
    background: #fef2f2;
    color: #dc2626;
    border: 1px solid #fecaca;
  }
  
  /* Utilities */
  .flex { display: flex; }
  .items-center { align-items: center; }
  .justify-between { justify-content: space-between; }
  .gap-2 { gap: 0.5rem; }
  .gap-4 { gap: 1rem; }
  .mb-4 { margin-bottom: 1rem; }
  .mt-4 { margin-top: 1rem; }
  
  /* Responsive */
  @media (max-width: 768px) {
    .navbar-container {
      flex-direction: column;
      height: auto;
      padding: 1rem;
    }
    
    .tab-navigation {
      margin-top: 1rem;
      flex-wrap: wrap;
    }
    
    .cards-grid {
      grid-template-columns: 1fr;
    }
    
    .main-content {
      padding: 1rem;
    }
  }
`;

const loginPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Login - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      html,body,#root{height:100%;margin:0;font-family:Arial, sans-serif}
      .login-container{display:flex;justify-content:center;align-items:center;height:100vh;background:#f5f5f5}
      .login-form{background:white;padding:2rem;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,0.1);max-width:400px;width:100%}
      .form-title{text-align:center;color:#1976d2;margin-bottom:1.5rem;font-size:1.5rem}
      .form-group{margin-bottom:1rem}
      .form-label{display:block;margin-bottom:0.25rem;font-weight:500;color:#333}
      .form-input{width:100%;padding:0.75rem;border:1px solid #ddd;border-radius:4px;font-size:1rem;box-sizing:border-box}
      .form-input:focus{outline:none;border-color:#1976d2}
      .login-button{width:100%;background:#1976d2;color:white;padding:0.75rem;border:none;border-radius:4px;font-size:1rem;cursor:pointer;margin-top:0.5rem}
      .login-button:hover{background:#1565c0}
      .error-message{color:#d32f2f;font-size:0.875rem;margin-top:0.5rem;text-align:center}
      .success-message{color:#4caf50;font-size:0.875rem;margin-top:0.5rem;text-align:center}
    </style>
  </head>
  <body>
    <div id="root" class="login-container">
      <div class="login-form">
        <h2 class="form-title">Sistema Jurídico</h2>
        <form>
          <div class="form-group">
            <label class="form-label" for="username">Usuário:</label>
            <input type="text" class="form-input" id="username" name="username" />
          </div>
          <div class="form-group">
            <label class="form-label" for="password">Senha:</label>
            <input type="password" class="form-input" id="password" name="password" />
          </div>
          <button type="button" class="login-button" onclick="performLogin()">Entrar</button>
          <div class="error-message" id="error-message" style="display: none;"></div>
          <div class="success-message" id="success-message" style="display: none;">Bem-vindo</div>
        </form>
      </div>
    </div>

    <script>
      function performLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorMsg = document.getElementById('error-message');
        const successMsg = document.getElementById('success-message');

        errorMsg.style.display = 'none';
        successMsg.style.display = 'none';

        if (!username || !password) {
          errorMsg.textContent = 'Por favor, preencha todos os campos';
          errorMsg.style.display = 'block';
          return;
        }

        if (username === 'user@test.com' && password === '123456') {
          successMsg.style.display = 'block';
          setTimeout(() => {
            window.location.href = '/dashboard';
          }, 1000);
        } else {
          errorMsg.textContent = 'Credenciais inválidas';
          errorMsg.style.display = 'block';
        }
      }

      // Handle Enter key
      document.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
          performLogin();
        }
      });
    </script>
  </body>
</html>
`;

const dashboardPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Dashboard - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">Sistema Jurídico</a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link active">Dashboard</a>
            <a href="/users" class="tab-link">Usuários</a>
            <a href="/cases" class="tab-link">Casos</a>
            <a href="/documents" class="tab-link">Documentos</a>
            <a href="/hearings" class="tab-link">Audiências</a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Dashboard</h1>
          <p class="page-subtitle">Visão geral do sistema jurídico</p>
        </div>
        
        <div class="cards-grid">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">👥</div>
              <div class="card-title">Usuários</div>
            </div>
            <p class="card-description">Gerencie usuários do sistema, adicione novos advogados e funcionários</p>
            <a href="/users" class="btn btn-primary">Gerenciar Usuários</a>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">⚖️</div>
              <div class="card-title">Casos Jurídicos</div>
            </div>
            <p class="card-description">Acompanhe processos judiciais, gerencie prazos e documentação</p>
            <a href="/cases" class="btn btn-primary">Ver Casos</a>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📄</div>
              <div class="card-title">Documentos</div>
            </div>
            <p class="card-description">Organize documentos legais, contratos e petições do escritório</p>
            <a href="/documents" class="btn btn-primary">Gerenciar Documentos</a>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">🏛️</div>
              <div class="card-title">Audiências</div>
            </div>
            <p class="card-description">Agende audiências, gerencie calendário e notificações</p>
            <a href="/hearings" class="btn btn-primary">Ver Audiências</a>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📊</div>
              <div class="card-title">Estatísticas do Mês</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">24</div>
                <div style="font-size: 0.875rem; color: #64748b;">Casos Ativos</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">12</div>
                <div style="font-size: 0.875rem; color: #64748b;">Audiências</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">156</div>
                <div style="font-size: 0.875rem; color: #64748b;">Documentos</div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">⏰</div>
              <div class="card-title">Próximas Atividades</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="margin-bottom: 0.5rem;">• Audiência - Caso Silva vs. Santos - 15/01/2026</div>
              <div style="margin-bottom: 0.5rem;">• Prazo para contestação - Caso Oliveira - 18/01/2026</div>
              <div style="margin-bottom: 0.5rem;">• Reunião com cliente - Maria Costa - 20/01/2026</div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <script>
      function logout() {
        if (confirm('Tem certeza que deseja sair?')) {
          window.location.href = '/login';
        }
      }
    </script>
  </body>
</html>
`;

const usersPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Usuários - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">Sistema Jurídico</a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link">Dashboard</a>
            <a href="/users" class="tab-link active">Usuários</a>
            <a href="/cases" class="tab-link">Casos</a>
            <a href="/documents" class="tab-link">Documentos</a>
            <a href="/hearings" class="tab-link">Audiências</a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Gerenciamento de Usuários</h1>
          <p class="page-subtitle">Administre usuários, permissões e perfis do sistema</p>
          <button class="btn btn-primary" onclick="openUserModal()">+ Novo Usuário</button>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Lista de Usuários</div>
            <div class="search-container">
              <input type="text" id="userSearch" placeholder="Buscar usuários..." style="padding: 0.5rem; border: 1px solid #e1e5e9; border-radius: 0.375rem; font-size: 0.875rem;">
            </div>
          </div>
          
          <div id="message" style="display:none;padding:1rem;margin:1rem;border-radius:0.5rem;"></div>
          
          <div class="table-container">
            <table class="table" id="users-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nome</th>
                  <th>Email</th>
                  <th>Papel</th>
                  <th>Status</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="users-tbody">
                <!-- Users will be loaded here -->
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📈</div>
              <div class="card-title">Estatísticas de Usuários</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">15</div>
                <div style="font-size: 0.875rem; color: #64748b;">Total de Usuários</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">12</div>
                <div style="font-size: 0.875rem; color: #64748b;">Usuários Ativos</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">3</div>
                <div style="font-size: 0.875rem; color: #64748b;">Pendentes</div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">👤</div>
              <div class="card-title">Perfis de Acesso</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Advogados</span>
                <span style="font-weight: 600;">8 usuários</span>
              </div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Secretárias</span>
                <span style="font-weight: 600;">4 usuários</span>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span>Administradores</span>
                <span style="font-weight: 600;">3 usuários</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- User Modal -->
    <div id="userModal" class="modal">
      <div class="modal-content">
        <span class="modal-close" onclick="closeUserModal()">&times;</span>
        <h3 id="modal-title">Adicionar Usuário</h3>
        <form id="userForm">
          <div class="form-group">
            <label class="form-label">Nome:</label>
            <input type="text" class="form-input" id="userName" required />
          </div>
          <div class="form-group">
            <label class="form-label">Email:</label>
            <input type="email" class="form-input" id="userEmail" required />
          </div>
          <div class="form-group">
            <label class="form-label">Papel:</label>
            <select class="form-input" id="userRole">
              <option value="user">Usuário</option>
              <option value="lawyer">Advogado</option>
              <option value="client">Cliente</option>
              <option value="admin">Administrador</option>
            </select>
          </div>
          <button type="submit" class="btn">Salvar</button>
          <button type="button" class="btn btn-danger" onclick="closeUserModal()">Cancelar</button>
        </form>
      </div>
    </div>

    <script>
      let users = [];
      let editingUserId = null;

      async function loadUsers() {
        try {
          const response = await fetch('http://localhost:3333/users');
          users = await response.json();
          renderUsers();
        } catch (error) {
          showMessage('Erro ao carregar usuários', 'error');
        }
      }

      function renderUsers() {
        const tbody = document.getElementById('users-tbody');
        tbody.innerHTML = users.map(user => 
          \`<tr>
            <td>\${user.id}</td>
            <td>\${user.name}</td>
            <td>\${user.email}</td>
            <td>\${user.role}</td>
            <td>\${user.active ? 'Ativo' : 'Inativo'}</td>
            <td>
              <button class="btn" onclick="editUser(\${user.id})">Editar</button>
              <button class="btn btn-danger" onclick="deleteUser(\${user.id})">Excluir</button>
            </td>
          </tr>\`
        ).join('');
      }

      function openUserModal(user = null) {
        const modal = document.getElementById('userModal');
        const title = document.getElementById('modal-title');
        
        if (user) {
          title.textContent = 'Editar Usuário';
          document.getElementById('userName').value = user.name;
          document.getElementById('userEmail').value = user.email;
          document.getElementById('userRole').value = user.role;
          editingUserId = user.id;
        } else {
          title.textContent = 'Adicionar Usuário';
          document.getElementById('userForm').reset();
          editingUserId = null;
        }
        
        modal.classList.add('show');
      }

      function closeUserModal() {
        document.getElementById('userModal').classList.remove('show');
      }

      function editUser(id) {
        const user = users.find(u => u.id === id);
        if (user) openUserModal(user);
      }

      async function deleteUser(id) {
        if (!confirm('Tem certeza que deseja excluir este usuário?')) return;
        
        try {
          await fetch('http://localhost:3333/users/' + id, { method: 'DELETE' });
          showMessage('Usuário excluído com sucesso', 'success');
          loadUsers();
        } catch (error) {
          showMessage('Erro ao excluir usuário', 'error');
        }
      }

      function showMessage(text, type) {
        const message = document.getElementById('message');
        message.textContent = text;
        message.className = type;
        message.style.display = 'block';
        setTimeout(() => message.style.display = 'none', 3000);
      }

      function logout() {
        window.location.href = '/login';
      }

      document.getElementById('userForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const userData = {
          name: document.getElementById('userName').value,
          email: document.getElementById('userEmail').value,
          role: document.getElementById('userRole').value
        };

        try {
          const url = editingUserId ? 
            'http://localhost:3333/users/' + editingUserId : 
            'http://localhost:3333/users';
          const method = editingUserId ? 'PUT' : 'POST';

          await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
          });

          showMessage(\`Usuário \${editingUserId ? 'atualizado' : 'criado'} com sucesso\`, 'success');
          closeUserModal();
          loadUsers();
        } catch (error) {
          showMessage('Erro ao salvar usuário', 'error');
        }
      });

      // Load users on page load
      loadUsers();
    </script>
  </body>
</html>
`;

const casesPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Casos - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">Sistema Jurídico</a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link">Dashboard</a>
            <a href="/users" class="tab-link">Usuários</a>
            <a href="/cases" class="tab-link active">Casos</a>
            <a href="/documents" class="tab-link">Documentos</a>
            <a href="/hearings" class="tab-link">Audiências</a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Gerenciamento de Casos</h1>
          <p class="page-subtitle">Acompanhe processos judiciais e gerencie documentação</p>
          <button class="btn btn-primary" onclick="openCaseModal()">+ Novo Caso</button>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Lista de Casos Jurídicos</div>
            <div class="search-container">
              <input type="text" id="caseSearch" placeholder="Buscar casos..." style="padding: 0.5rem; border: 1px solid #e1e5e9; border-radius: 0.375rem; font-size: 0.875rem;">
            </div>
          </div>
          
          <div id="message" style="display:none;padding:1rem;margin:1rem;border-radius:0.5rem;"></div>
          
          <div class="table-container">
            <table class="table" id="cases-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Título</th>
                  <th>Categoria</th>
                  <th>Status</th>
                  <th>Prioridade</th>
                  <th>Data Criação</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="cases-tbody">
                <!-- Cases will be loaded here -->
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📊</div>
              <div class="card-title">Estatísticas de Casos</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">24</div>
                <div style="font-size: 0.875rem; color: #64748b;">Casos Ativos</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">8</div>
                <div style="font-size: 0.875rem; color: #64748b;">Finalizados</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">5</div>
                <div style="font-size: 0.875rem; color: #64748b;">Urgentes</div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">⚖️</div>
              <div class="card-title">Categorias de Casos</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Civil</span>
                <span style="font-weight: 600;">12 casos</span>
              </div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Trabalhista</span>
                <span style="font-weight: 600;">8 casos</span>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span>Criminal</span>
                <span style="font-weight: 600;">4 casos</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Case Modal -->
    <div id="caseModal" class="modal">
      <div class="modal-content">
        <span class="modal-close" onclick="closeCaseModal()">&times;</span>
        <h3 id="modal-title">Adicionar Caso</h3>
        <form id="caseForm">
          <div class="form-group">
            <label class="form-label">Título:</label>
            <input type="text" class="form-input" id="caseTitle" required />
          </div>
          <div class="form-group">
            <label class="form-label">Descrição:</label>
            <textarea class="form-input" id="caseDescription" rows="3"></textarea>
          </div>
          <div class="form-group">
            <label class="form-label">Categoria:</label>
            <select class="form-input" id="caseCategory">
              <option value="civil">Civil</option>
              <option value="criminal">Criminal</option>
              <option value="trabalhista">Trabalhista</option>
              <option value="tributario">Tributário</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Prioridade:</label>
            <select class="form-input" id="casePriority">
              <option value="low">Baixa</option>
              <option value="medium">Média</option>
              <option value="high">Alta</option>
            </select>
          </div>
          <button type="submit" class="btn">Salvar</button>
          <button type="button" class="btn btn-danger" onclick="closeCaseModal()">Cancelar</button>
        </form>
      </div>
    </div>

    <script>
      let cases = [];
      let editingCaseId = null;

      async function loadCases() {
        try {
          const response = await fetch('http://localhost:3333/litigation/cases');
          cases = await response.json();
          renderCases();
        } catch (error) {
          showMessage('Erro ao carregar casos', 'error');
        }
      }

      function renderCases() {
        const tbody = document.getElementById('cases-tbody');
        tbody.innerHTML = cases.map(caseItem => 
          \`<tr>
            <td>\${caseItem.id}</td>
            <td>\${caseItem.title}</td>
            <td>\${caseItem.category}</td>
            <td>\${caseItem.status}</td>
            <td>\${caseItem.priority}</td>
            <td>\${new Date(caseItem.createdAt).toLocaleDateString()}</td>
            <td>
              <button class="btn" onclick="viewCase(\${caseItem.id})">Ver</button>
              <button class="btn" onclick="editCase(\${caseItem.id})">Editar</button>
              <button class="btn btn-danger" onclick="deleteCase(\${caseItem.id})">Excluir</button>
            </td>
          </tr>\`
        ).join('');
      }

      function openCaseModal(caseItem = null) {
        const modal = document.getElementById('caseModal');
        const title = document.getElementById('modal-title');
        
        if (caseItem) {
          title.textContent = 'Editar Caso';
          document.getElementById('caseTitle').value = caseItem.title;
          document.getElementById('caseDescription').value = caseItem.description;
          document.getElementById('caseCategory').value = caseItem.category;
          document.getElementById('casePriority').value = caseItem.priority;
          editingCaseId = caseItem.id;
        } else {
          title.textContent = 'Adicionar Caso';
          document.getElementById('caseForm').reset();
          editingCaseId = null;
        }
        
        modal.classList.add('show');
      }

      function closeCaseModal() {
        document.getElementById('caseModal').classList.remove('show');
      }

      function viewCase(id) {
        window.location.href = \`/case-details?id=\${id}\`;
      }

      function editCase(id) {
        const caseItem = cases.find(c => c.id === id);
        if (caseItem) openCaseModal(caseItem);
      }

      async function deleteCase(id) {
        if (!confirm('Tem certeza que deseja excluir este caso?')) return;
        
        try {
          await fetch('http://localhost:3333/litigation/cases/' + id, { method: 'DELETE' });
          showMessage('Caso excluído com sucesso', 'success');
          loadCases();
        } catch (error) {
          showMessage('Erro ao excluir caso', 'error');
        }
      }

      function showMessage(text, type) {
        const message = document.getElementById('message');
        message.textContent = text;
        message.className = type;
        message.style.display = 'block';
        setTimeout(() => message.style.display = 'none', 3000);
      }

      function logout() {
        window.location.href = '/login';
      }

      document.getElementById('caseForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const caseData = {
          title: document.getElementById('caseTitle').value,
          description: document.getElementById('caseDescription').value,
          category: document.getElementById('caseCategory').value,
          priority: document.getElementById('casePriority').value,
          status: 'active'
        };

        try {
          const url = editingCaseId ? 
            'http://localhost:3333/litigation/cases/' + editingCaseId : 
            'http://localhost:3333/litigation/cases';
          const method = editingCaseId ? 'PUT' : 'POST';

          await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(caseData)
          });

          showMessage(\`Caso \${editingCaseId ? 'atualizado' : 'criado'} com sucesso\`, 'success');
          closeCaseModal();
          loadCases();
        } catch (error) {
          showMessage('Erro ao salvar caso', 'error');
        }
      });

      // Load cases on page load
      loadCases();
    </script>
  </body>
</html>
`;

const documentsPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Documentos - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">Sistema Jurídico</a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link">Dashboard</a>
            <a href="/users" class="tab-link">Usuários</a>
            <a href="/cases" class="tab-link">Casos</a>
            <a href="/documents" class="tab-link active">Documentos</a>
            <a href="/hearings" class="tab-link">Audiências</a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Gerenciamento de Documentos</h1>
          <p class="page-subtitle">Organize e gerencie documentos legais e contratos</p>
          <button class="btn btn-primary" onclick="openDocModal()">+ Novo Documento</button>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Biblioteca de Documentos</div>
            <div class="search-container">
              <input type="text" id="docSearch" placeholder="Buscar documentos..." style="padding: 0.5rem; border: 1px solid #e1e5e9; border-radius: 0.375rem; font-size: 0.875rem;">
            </div>
          </div>
          
          <div id="message" style="display:none;padding:1rem;margin:1rem;border-radius:0.5rem;"></div>
          
          <div class="table-container">
            <table class="table" id="documents-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nome</th>
                  <th>Tipo</th>
                  <th>Caso ID</th>
                  <th>Data Upload</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="documents-tbody">
                <!-- Documents will be loaded here -->
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📊</div>
              <div class="card-title">Estatísticas de Documentos</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">156</div>
                <div style="font-size: 0.875rem; color: #64748b;">Total Documentos</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">42</div>
                <div style="font-size: 0.875rem; color: #64748b;">Este Mês</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">8</div>
                <div style="font-size: 0.875rem; color: #64748b;">Pendentes</div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📄</div>
              <div class="card-title">Tipos de Documentos</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Petições</span>
                <span style="font-weight: 600;">45 docs</span>
              </div>
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                <span>Contratos</span>
                <span style="font-weight: 600;">38 docs</span>
              </div>
              <div style="display: flex; justify-content: space-between;">
                <span>Evidências</span>
                <span style="font-weight: 600;">73 docs</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Document Modal -->
    <div id="docModal" class="modal">
      <div class="modal-content">
        <span class="modal-close" onclick="closeDocModal()">&times;</span>
        <h3>Adicionar Documento</h3>
        <form id="docForm">
          <div class="form-group">
            <label class="form-label">Nome do Documento:</label>
            <input type="text" class="form-input" id="docName" required />
          </div>
          <div class="form-group">
            <label class="form-label">Tipo:</label>
            <select class="form-input" id="docType">
              <option value="petition">Petição</option>
              <option value="evidence">Evidência</option>
              <option value="contract">Contrato</option>
              <option value="ruling">Decisão</option>
              <option value="other">Outro</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">ID do Caso:</label>
            <input type="number" class="form-input" id="docCaseId" required />
          </div>
          <div class="form-group">
            <label class="form-label">Arquivo (Simulado):</label>
            <input type="file" class="form-input" id="docFile" />
          </div>
          <button type="submit" class="btn">Salvar</button>
          <button type="button" class="btn btn-danger" onclick="closeDocModal()">Cancelar</button>
        </form>
      </div>
    </div>

    <script>
      let documents = [];

      async function loadDocuments() {
        try {
          const response = await fetch('http://localhost:3333/documents');
          documents = await response.json();
          renderDocuments();
        } catch (error) {
          showMessage('Erro ao carregar documentos', 'error');
        }
      }

      function renderDocuments() {
        const tbody = document.getElementById('documents-tbody');
        tbody.innerHTML = documents.map(doc => 
          \`<tr>
            <td>\${doc.id}</td>
            <td>\${doc.name}</td>
            <td>\${doc.type}</td>
            <td>\${doc.caseId}</td>
            <td>\${new Date(doc.uploadedAt).toLocaleDateString()}</td>
            <td>
              <button class="btn" onclick="downloadDoc(\${doc.id})">Download</button>
              <button class="btn btn-danger" onclick="deleteDoc(\${doc.id})">Excluir</button>
            </td>
          </tr>\`
        ).join('');
      }

      function openDocModal() {
        document.getElementById('docModal').classList.add('show');
      }

      function closeDocModal() {
        document.getElementById('docModal').classList.remove('show');
      }

      function downloadDoc(id) {
        showMessage('Download iniciado (simulado)', 'success');
      }

      async function deleteDoc(id) {
        if (!confirm('Tem certeza que deseja excluir este documento?')) return;
        
        try {
          const response = await fetch('http://localhost:3333/documents/' + id, {
            method: 'DELETE'
          });

          if (response.ok) {
            showMessage('Documento excluído com sucesso', 'success');
            loadDocuments(); // Reload from API
          } else {
            throw new Error('Failed to delete document');
          }
        } catch (error) {
          showMessage('Erro ao excluir documento', 'error');
        }
      }

      function showMessage(text, type) {
        const message = document.getElementById('message');
        message.textContent = text;
        message.className = type;
        message.style.display = 'block';
        setTimeout(() => message.style.display = 'none', 3000);
      }

      function logout() {
        window.location.href = '/login';
      }

      document.getElementById('docForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const docData = {
          name: document.getElementById('docName').value,
          type: document.getElementById('docType').value,
          caseId: parseInt(document.getElementById('docCaseId').value)
        };

        try {
          const response = await fetch('http://localhost:3333/documents', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(docData)
          });

          if (response.ok) {
            showMessage('Documento adicionado com sucesso', 'success');
            closeDocModal();
            document.getElementById('docForm').reset();
            loadDocuments(); // Reload from API
          } else {
            throw new Error('Failed to create document');
          }
        } catch (error) {
          showMessage('Erro ao salvar documento', 'error');
        }
      });

      loadDocuments();
    </script>
  </body>
</html>
`;

const hearingsPage = `
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Audiências - Sistema Jurídico</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>${commonStyles}</style>
  </head>
  <body>
    <div class="app-container">
      <nav class="navbar">
        <div class="navbar-container">
          <a href="/dashboard" class="navbar-brand">Sistema Jurídico</a>
          <div class="tab-navigation">
            <a href="/dashboard" class="tab-link">Dashboard</a>
            <a href="/users" class="tab-link">Usuários</a>
            <a href="/cases" class="tab-link">Casos</a>
            <a href="/documents" class="tab-link">Documentos</a>
            <a href="/hearings" class="tab-link active">Audiências</a>
          </div>
          <div class="user-menu">
            <span class="user-info">Bem-vindo, user@test.com</span>
            <button class="logout-btn" onclick="logout()">Sair</button>
          </div>
        </div>
      </nav>
      
      <main class="main-content">
        <div class="page-header">
          <h1 class="page-title">Gerenciamento de Audiências</h1>
          <p class="page-subtitle">Agende audiências e gerencie calendário judicial</p>
          <button class="btn btn-primary" onclick="openHearingModal()">+ Nova Audiência</button>
        </div>
        
        <div class="card">
          <div class="card-header">
            <div class="card-title">Calendário de Audiências</div>
            <div class="search-container">
              <input type="text" id="hearingSearch" placeholder="Buscar audiências..." style="padding: 0.5rem; border: 1px solid #e1e5e9; border-radius: 0.375rem; font-size: 0.875rem;">
            </div>
          </div>
          
          <div id="message" style="display:none;padding:1rem;margin:1rem;border-radius:0.5rem;"></div>
          
          <div class="table-container">
            <table class="table" id="hearings-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Tipo</th>
                  <th>Data/Hora</th>
                  <th>Local</th>
                  <th>Caso ID</th>
                  <th>Status</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="hearings-tbody">
                <!-- Hearings will be loaded here -->
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="cards-grid mt-4">
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📅</div>
              <div class="card-title">Próximas Audiências</div>
            </div>
            <div style="font-size: 0.875rem; color: #64748b; line-height: 1.6;">
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 0; border-bottom: 1px solid #f1f5f9;">
                <div>
                  <div style="font-weight: 600; color: #1f2937;">Audiência Inicial</div>
                  <div style="color: #64748b;">Caso Silva vs. Santos</div>
                </div>
                <div style="text-align: right;">
                  <div style="font-weight: 600; color: #667eea;">15/01/2026</div>
                  <div style="color: #64748b;">14:30</div>
                </div>
              </div>
              <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 0; border-bottom: 1px solid #f1f5f9;">
                <div>
                  <div style="font-weight: 600; color: #1f2937;">Conciliação</div>
                  <div style="color: #64748b;">Caso Oliveira vs. Empresa</div>
                </div>
                <div style="text-align: right;">
                  <div style="font-weight: 600; color: #667eea;">18/01/2026</div>
                  <div style="color: #64748b;">09:00</div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-header">
              <div class="card-icon">📊</div>
              <div class="card-title">Estatísticas de Audiências</div>
            </div>
            <div class="flex justify-between items-center">
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #667eea;">12</div>
                <div style="font-size: 0.875rem; color: #64748b;">Este Mês</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #10b981;">8</div>
                <div style="font-size: 0.875rem; color: #64748b;">Realizadas</div>
              </div>
              <div>
                <div style="font-size: 1.875rem; font-weight: 700; color: #f59e0b;">4</div>
                <div style="font-size: 0.875rem; color: #64748b;">Agendadas</div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <!-- Hearing Modal -->
    <div id="hearingModal" class="modal">
      <div class="modal-content">
        <span class="modal-close" onclick="closeHearingModal()">&times;</span>
        <h3>Agendar Audiência</h3>
        <form id="hearingForm">
          <div class="form-group">
            <label class="form-label">Tipo:</label>
            <select class="form-input" id="hearingType">
              <option value="initial">Inicial</option>
              <option value="testimony">Testemunhal</option>
              <option value="conciliation">Conciliação</option>
              <option value="judgment">Julgamento</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Data:</label>
            <input type="date" class="form-input" id="hearingDate" required />
          </div>
          <div class="form-group">
            <label class="form-label">Horário:</label>
            <input type="time" class="form-input" id="hearingTime" required />
          </div>
          <div class="form-group">
            <label class="form-label">Local:</label>
            <input type="text" class="form-input" id="hearingLocation" required />
          </div>
          <div class="form-group">
            <label class="form-label">ID do Caso:</label>
            <input type="number" class="form-input" id="hearingCaseId" required />
          </div>
          <button type="submit" class="btn">Agendar</button>
          <button type="button" class="btn btn-danger" onclick="closeHearingModal()">Cancelar</button>
        </form>
      </div>
    </div>

    <script>
      let hearings = [];

      async function loadHearings() {
        try {
          const response = await fetch('http://localhost:3333/hearings');
          hearings = await response.json();
          renderHearings();
        } catch (error) {
          showMessage('Erro ao carregar audiências', 'error');
        }
      }

      function renderHearings() {
        const tbody = document.getElementById('hearings-tbody');
        tbody.innerHTML = hearings.map(hearing => 
          \`<tr>
            <td>\${hearing.id}</td>
            <td>\${hearing.type}</td>
            <td>\${new Date(hearing.dateTime).toLocaleString()}</td>
            <td>\${hearing.location}</td>
            <td>\${hearing.caseId}</td>
            <td>\${hearing.status}</td>
            <td>
              <button class="btn" onclick="editHearing(\${hearing.id})">Editar</button>
              <button class="btn btn-danger" onclick="cancelHearing(\${hearing.id})">Cancelar</button>
            </td>
          </tr>\`
        ).join('');
      }

      function openHearingModal() {
        document.getElementById('hearingModal').classList.add('show');
      }

      function closeHearingModal() {
        document.getElementById('hearingModal').classList.remove('show');
      }

      function editHearing(id) {
        showMessage('Função de edição em desenvolvimento', 'success');
      }

      function cancelHearing(id) {
        if (!confirm('Tem certeza que deseja cancelar esta audiência?')) return;
        const hearing = hearings.find(h => h.id === id);
        if (hearing) {
          hearing.status = 'cancelled';
          renderHearings();
          showMessage('Audiência cancelada com sucesso', 'success');
        }
      }

      function showMessage(text, type) {
        const message = document.getElementById('message');
        message.textContent = text;
        message.className = type;
        message.style.display = 'block';
        setTimeout(() => message.style.display = 'none', 3000);
      }

      function logout() {
        window.location.href = '/login';
      }

      document.getElementById('hearingForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const hearingData = {
          type: document.getElementById('hearingType').value,
          date: document.getElementById('hearingDate').value,
          time: document.getElementById('hearingTime').value,
          location: document.getElementById('hearingLocation').value,
          caseId: parseInt(document.getElementById('hearingCaseId').value)
        };

        try {
          const response = await fetch('http://localhost:3333/hearings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(hearingData)
          });

          if (response.ok) {
            showMessage('Audiência agendada com sucesso', 'success');
            closeHearingModal();
            document.getElementById('hearingForm').reset();
            loadHearings(); // Reload from API
          } else {
            throw new Error('Failed to create hearing');
          }
        } catch (error) {
          showMessage('Erro ao agendar audiência', 'error');
        }
      });

      loadHearings();
    </script>
  </body>
</html>
`;

const server = http.createServer((req, res) => {
  const url = req.url;
  
  // Route handling
  if (req.method === 'GET' && url === '/login') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(loginPage);
    return;
  }
  
  if (req.method === 'GET' && url === '/dashboard') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(dashboardPage);
    return;
  }

  if (req.method === 'GET' && url === '/users') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(usersPage);
    return;
  }

  if (req.method === 'GET' && url === '/cases') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(casesPage);
    return;
  }

  if (req.method === 'GET' && url === '/documents') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(documentsPage);
    return;
  }

  if (req.method === 'GET' && url === '/hearings') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(hearingsPage);
    return;
  }
  
  // Default redirect to login for root
  if (req.method === 'GET' && (url === '/' || url === '')) {
    res.writeHead(302, { 'Location': '/login' });
    res.end();
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end('<h1>404 - Page Not Found</h1><p><a href="/login">Go to Login</a></p>');
});

const port = 3000;
server.listen(port, () => console.log(`Mock UI listening on http://localhost:${port}`));

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));