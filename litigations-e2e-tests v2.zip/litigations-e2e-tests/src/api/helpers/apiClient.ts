// src/api/helpers/apiClient.ts
import { request, APIRequestContext, APIResponse, expect } from '@playwright/test';

export class ApiClient {
  private context!: APIRequestContext;
  private readonly baseURL: string;
  private defaultHeaders: Record<string, string>;

  constructor(baseURL: string, defaultHeaders: Record<string, string> = {}) {
    this.baseURL = baseURL;
    this.defaultHeaders = {
      'Content-Type': 'application/json',
      ...defaultHeaders
    };
  }

  async init() {
    this.context = await request.newContext({
      baseURL: this.baseURL,
      extraHTTPHeaders: this.defaultHeaders
    });
  }

  async setAuthToken(token: string) {
    this.defaultHeaders = {
      ...this.defaultHeaders,
      Authorization: `Bearer ${token}`
    };

    // recria o contexto com o novo header
    await this.dispose();
    await this.init();
  }

  async get(path: string, params?: Record<string, string | number>): Promise<APIResponse> {
    return this.context.get(path, { params });
  }

  async post(path: string, body?: unknown): Promise<APIResponse> {
    return this.context.post(path, { data: body });
  }

  async put(path: string, body?: unknown): Promise<APIResponse> {
    return this.context.put(path, { data: body });
  }

  async patch(path: string, body?: unknown): Promise<APIResponse> {
    return this.context.patch(path, { data: body });
  }

  async delete(path: string): Promise<APIResponse> {
    return this.context.delete(path);
  }

  async expectStatus(response: APIResponse, status: number) {
    expect(response.status()).toBe(status);
  }

  async json<T>(response: APIResponse): Promise<T> {
    return (await response.json()) as T;
  }

  async dispose() {
    if (this.context) {
      await this.context.dispose();
    }
  }

}
