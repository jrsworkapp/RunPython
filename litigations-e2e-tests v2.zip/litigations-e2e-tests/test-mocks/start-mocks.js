// test-mocks/start-mocks.js
const { spawn } = require('child_process');
const fs = require('fs');

function start(script) {
  const child = spawn(process.execPath, [script], {
    detached: true,
    stdio: 'ignore',
  });
  child.unref();
  return child.pid;
}

const apiPid = start('test-mocks/mock-api.js');
const uiPid = start('test-mocks/mock-ui.js');
fs.writeFileSync('.mock_api_pid', String(apiPid));
fs.writeFileSync('.mock_ui_pid', String(uiPid));
console.log('Started mock API (pid=' + apiPid + ') and mock UI (pid=' + uiPid + ')');
